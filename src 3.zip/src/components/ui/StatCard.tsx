import React from "react";
import type { LucideIcon } from "lucide-react";

type Tone = "green" | "yellow" | "sand" | "deep" | "plain";

interface Props {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  icon?: LucideIcon;
  tone?: Tone;
}

/** Pastel bento tile for one number. */
const StatCard: React.FC<Props> = ({ label, value, hint, icon: Icon, tone = "plain" }) => (
  <div className={`stat-card stat-card--${tone}`}>
    <div className="flex items-start justify-between gap-3">
      <p className="stat-label">{label}</p>
      {Icon && (
        <span className="stat-icon">
          <Icon size={16} />
        </span>
      )}
    </div>
    <p className="stat-value mt-3">{value}</p>
    {hint && <p className="text-xs mt-1 opacity-70">{hint}</p>}
  </div>
);

export default StatCard;
