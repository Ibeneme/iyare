import React, { useEffect, useMemo, useRef, useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bell,
  ChevronDown,
  ChevronsUpDown,
  GraduationCap,
  LogOut,
  Menu,
  Moon,
  Search,
  Sun,
  X,
} from "lucide-react";
import Avatar from "../ui/Avatar";
import useAuth from "../../hooks/useAuth";
import { useTheme } from "../../contexts/ThemeContext";
import {
  FOOTER_ITEMS,
  NAV_ITEMS,
  navForRole,
  type NavItem,
} from "../../config/navigation";
import { ROLE_LABEL } from "../../config/roles";
import { PATHS } from "../../routes/paths";

/** True when another menu entry lives below this path */
const ALL_PATHS = [...NAV_ITEMS, ...FOOTER_ITEMS]
  .flatMap((i) => [i.path, ...(i.children?.map((c) => c.path) ?? [])])
  .filter(Boolean) as string[];
const hasSubPath = (p: string) =>
  ALL_PATHS.some((o) => o !== p && o.startsWith(p + "/"));

const linkClass = (active: boolean) =>
  `flex items-center gap-3 px-3 py-2.5 rounded-full text-sm font-medium transition-colors ${
    active
      ? "bg-[var(--color-sidebar-active-bg)] text-[var(--color-sidebar-active-text)]"
      : "text-[var(--color-sidebar-text)] hover:bg-white/10 hover:text-white"
  }`;

const Brand: React.FC = () => (
  <Link
    to="/"
    className="flex items-center gap-2.5"
    aria-label="Yare Height home"
  >
    <span className="w-9 h-9 rounded-xl bg-[var(--color-accent)] grid place-items-center">
      <GraduationCap size={18} className="text-[var(--color-accent-fg)]" />
    </span>
    <span className="font-semibold tracking-tight text-white">Yare Height</span>
  </Link>
);

const NavList: React.FC<{ items: NavItem[]; onNavigate?: () => void }> = ({
  items,
  onNavigate,
}) => {
  const { pathname } = useLocation();
  const [open, setOpen] = useState<string | null>(null);

  return (
    <ul className="space-y-0.5">
      {items.map((item) => {
        if (!item.children) {
          return (
            <li key={item.title}>
              <NavLink
                to={item.path!}
                end={hasSubPath(item.path!)}
                onClick={onNavigate}
                className={({ isActive }) => linkClass(isActive)}
              >
                <item.icon size={18} className="shrink-0" />
                <span className="truncate">{item.title}</span>
              </NavLink>
            </li>
          );
        }

        const childActive = item.children.some((c) =>
          pathname.startsWith(c.path!),
        );
        const expanded = open === item.title || childActive;

        return (
          <li key={item.title}>
            <button
              type="button"
              aria-expanded={expanded}
              onClick={() =>
                setOpen(expanded && !childActive ? null : item.title)
              }
              className={`w-full justify-between ${linkClass(childActive)}`}
            >
              <span className="flex items-center gap-3">
                <item.icon size={18} className="shrink-0" />
                {item.title}
              </span>
              <ChevronDown
                size={15}
                className={`transition-transform ${expanded ? "rotate-180" : ""}`}
              />
            </button>

            <AnimatePresence initial={false}>
              {expanded && (
                <motion.ul
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden ml-6 pl-3 border-l border-white/15 mt-0.5 space-y-0.5"
                >
                  {item.children.map((c) => (
                    <li key={c.title}>
                      <NavLink
                        to={c.path!}
                        onClick={onNavigate}
                        className={({ isActive }) =>
                          `block px-3 py-2 rounded-xl text-sm transition-colors ${
                            isActive
                              ? "text-[var(--color-accent)] font-semibold"
                              : "text-[var(--color-sidebar-text)] hover:text-white"
                          }`
                        }
                      >
                        {c.title}
                      </NavLink>
                    </li>
                  ))}
                </motion.ul>
              )}
            </AnimatePresence>
          </li>
        );
      })}
    </ul>
  );
};

/** Everything inside the panel; used by the desktop sidebar and the mobile drawer. */
const PanelContent: React.FC<{
  onNavigate?: () => void;
  onClose?: () => void;
}> = ({ onNavigate, onClose }) => {
  const { role, displayName, email, logout, isSuperAdmin, user } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const [query, setQuery] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);

  // Press "/" anywhere to jump to the menu search
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (
        e.key === "/" &&
        tag !== "INPUT" &&
        tag !== "TEXTAREA" &&
        tag !== "SELECT"
      ) {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const main = useMemo(
    () => navForRole(role, NAV_ITEMS, isSuperAdmin),
    [role, isSuperAdmin],
  );
  const footer = useMemo(
    () => navForRole(role, FOOTER_ITEMS, isSuperAdmin),
    [role, isSuperAdmin],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return main;
    const flat: NavItem[] = [];
    main.forEach((i) =>
      i.children
        ? flat.push(
            ...i.children.map((c) => ({
              ...c,
              title: `${i.title} · ${c.title}`,
            })),
          )
        : flat.push(i),
    );
    return flat.filter((i) => i.title.toLowerCase().includes(q));
  }, [main, query]);

  return (
    <div className="flex flex-col h-full">
      {/* ========== SCROLLABLE AREA (everything except profile) ========== */}
      <div
        className="
          flex-1 overflow-y-auto -mx-1 px-1
          [&::-webkit-scrollbar]:w-1.5
          [&::-webkit-scrollbar-track]:bg-transparent
          [&::-webkit-scrollbar-thumb]:rounded-full
          [&::-webkit-scrollbar-thumb]:bg-[var(--color-accent)]
          [&::-webkit-scrollbar-thumb]:hover:bg-[var(--color-accent)]
        "
      >
        {/* Header */}
        <div className="flex items-center justify-between px-2 pt-1">
          <Brand />
          <div className="flex items-center gap-1">
            <Link
              to={PATHS.notifications}
              onClick={onNavigate}
              aria-label="Notifications"
              className="w-9 h-9 grid place-items-center rounded-full text-[var(--color-sidebar-text)] hover:bg-white/10 hover:text-white transition-colors"
            >
              <Bell size={18} />
            </Link>
            {onClose && (
              <button
                onClick={onClose}
                aria-label="Close menu"
                className="w-9 h-9 grid place-items-center rounded-full text-[var(--color-sidebar-text)] hover:bg-white/10"
              >
                <X size={18} />
              </button>
            )}
          </div>
        </div>

        {/* Search */}
        <div className="relative mt-4 px-1">
          <Search
            size={15}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none"
          />
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search"
            aria-label="Search menu"
            className="w-full h-10 pl-9 pr-9 rounded-full bg-white/10 text-sm text-white placeholder:text-white/50 outline-none border border-white/10 focus:border-[var(--color-accent)]"
          />
          <kbd className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[11px] text-white/70 bg-white/10 rounded-md px-1.5 py-0.5">
            /
          </kbd>
        </div>

        {/* Main navigation */}
        <nav aria-label="Main" className="mt-3">
          {filtered.length ? (
            <NavList items={filtered} onNavigate={onNavigate} />
          ) : (
            <p className="text-xs text-white/60 px-3 py-4">No matches</p>
          )}
        </nav>

        {/* Footer links + Theme + Logout */}
        <div className="mt-4 pt-3 space-y-0.5 border-t border-white/10 pb-2">
          {footer.map((i) => (
            <NavLink
              key={i.title}
              to={i.path!}
              end={hasSubPath(i.path!)}
              onClick={onNavigate}
              className={({ isActive }) => linkClass(isActive)}
            >
              <i.icon size={18} className="shrink-0" />
              {i.title}
            </NavLink>
          ))}

          <button
            onClick={toggleTheme}
            className={`w-full ${linkClass(false)}`}
          >
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
            {isDark ? "Light mode" : "Dark mode"}
          </button>

          <button
            onClick={logout}
            className={`w-full ${linkClass(false)} hover:!text-[var(--color-danger)]`}
          >
            <LogOut size={18} />
            Sign out
          </button>
        </div>
      </div>

      {/* ========== FIXED PROFILE (always at the bottom) ========== */}
      <div className="mt-2 pt-3 border-t border-white/10 shrink-0">
        <div className="flex items-center gap-3 rounded-2xl bg-white/10 p-2.5">
          <Avatar
            name={displayName}
            email={email}
            src={user?.avatarUrl || user?.profilePicture}
            size={36}
          />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-white truncate">
              {displayName}
            </p>
            <p className="text-xs text-white/60 truncate">
              {email || (role ? ROLE_LABEL[role] : "")}
            </p>
          </div>
          <ChevronsUpDown size={15} className="text-white/40 shrink-0" />
        </div>
      </div>
    </div>
  );
};

const Sidebar: React.FC = () => {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const { isDark } = useTheme();

  useEffect(() => setOpen(false), [pathname]);

  // Dark = #ffffff08 background | Light = solid CSS variable
  const sidebarBg = isDark
    ? "bg-[#ffffff08] backdrop-blur-xl border border-white/10"
    : "bg-[var(--color-sidebar-bg)]";

  return (
    <>
      {/* Desktop: floating panel */}
      <aside
        aria-label="Sidebar"
        className={`hidden lg:block fixed left-4 top-4 bottom-4 w-[15.5rem] rounded-[1.75rem] p-4 z-40 ${sidebarBg}`}
        style={{ boxShadow: "var(--shadow-elevated)" }}
      >
        <PanelContent />
      </aside>

      {/* Mobile / tablet: top bar + drawer */}
      <header
        className={`lg:hidden fixed top-0 inset-x-0 h-14 z-40 flex items-center justify-between px-4 ${sidebarBg}`}
      >
        <Brand />
        <button
          onClick={() => setOpen(true)}
          aria-label="Open menu"
          className="w-10 h-10 grid place-items-center rounded-full bg-white/10 text-white"
        >
          <Menu size={18} />
        </button>
      </header>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="lg:hidden fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
            />
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 320 }}
              className={`lg:hidden fixed left-3 top-3 bottom-3 w-[min(20rem,calc(100vw-1.5rem))] rounded-[1.75rem] p-4 z-50 ${sidebarBg}`}
              style={{ boxShadow: "var(--shadow-elevated)" }}
            >
              <PanelContent
                onNavigate={() => setOpen(false)}
                onClose={() => setOpen(false)}
              />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Sidebar;
