import React from "react";
import { motion } from "framer-motion";

type ShapeProps = {
  size?: number;
  color?: string;
  className?: string;
  style?: React.CSSProperties;
  /** Turn animation off if needed */
  animate?: boolean;
};

/** Six-armed asterisk — soft twinkle + gentle spin */
export const Sparkle: React.FC<ShapeProps> = ({
  size = 28,
  color = "var(--lp-yellow)",
  className = "",
  style,
  animate = true,
}) => (
  <motion.svg
    aria-hidden="true"
    width={size}
    height={size}
    viewBox="0 0 24 24"
    className={className}
    style={style}
    fill="none"
    stroke={color}
    strokeWidth="2.6"
    strokeLinecap="round"
    initial={false}
    animate={
      animate
        ? {
            rotate: [0, 15, -10, 0],
            scale: [1, 1.12, 0.96, 1],
            opacity: [0.85, 1, 0.9, 0.85],
          }
        : undefined
    }
    transition={{
      duration: 4.5,
      repeat: Infinity,
      ease: "easeInOut",
    }}
  >
    <path d="M12 2v20M3.3 7l17.4 10M3.3 17 20.7 7" />
  </motion.svg>
);

/** Concentric ring — slow continuous rotation + soft breathe */
export const Ring: React.FC<ShapeProps> = ({
  size = 34,
  color = "var(--lp-green-mid)",
  className = "",
  style,
  animate = true,
}) => (
  <motion.svg
    aria-hidden="true"
    width={size}
    height={size}
    viewBox="0 0 34 34"
    className={className}
    style={style}
    fill="none"
    stroke={color}
    strokeWidth="1.8"
    initial={false}
    animate={
      animate
        ? {
            rotate: 360,
            scale: [1, 1.06, 1],
          }
        : undefined
    }
    transition={{
      rotate: { duration: 18, repeat: Infinity, ease: "linear" },
      scale: { duration: 5.5, repeat: Infinity, ease: "easeInOut" },
    }}
  >
    <circle cx="17" cy="17" r="15" />
    <circle cx="17" cy="17" r="7" />
  </motion.svg>
);

/** Plus sign — gentle sway + pulse */
export const Plus: React.FC<ShapeProps> = ({
  size = 18,
  color = "var(--lp-green-mid)",
  className = "",
  style,
  animate = true,
}) => (
  <motion.svg
    aria-hidden="true"
    width={size}
    height={size}
    viewBox="0 0 18 18"
    className={className}
    style={style}
    fill="none"
    stroke={color}
    strokeWidth="3"
    strokeLinecap="round"
    initial={false}
    animate={
      animate
        ? {
            rotate: [0, 12, -8, 0],
            scale: [1, 1.15, 0.95, 1],
          }
        : undefined
    }
    transition={{
      duration: 5.2,
      repeat: Infinity,
      ease: "easeInOut",
    }}
  >
    <path d="M9 2v14M2 9h14" />
  </motion.svg>
);

/** Little squiggle underline — soft horizontal drift + opacity breathe */
export const Squiggle: React.FC<ShapeProps> = ({
  size = 90,
  color = "var(--lp-yellow)",
  className = "",
  style,
  animate = true,
}) => (
  <motion.svg
    aria-hidden="true"
    width={size}
    height={size * 0.16}
    viewBox="0 0 90 14"
    className={className}
    style={style}
    fill="none"
    stroke={color}
    strokeWidth="3.2"
    strokeLinecap="round"
    initial={false}
    animate={
      animate
        ? {
            x: [0, 4, -3, 0],
            opacity: [0.75, 1, 0.8, 0.75],
          }
        : undefined
    }
    transition={{
      duration: 4.8,
      repeat: Infinity,
      ease: "easeInOut",
    }}
  >
    <path d="M3 8c8-8 12 8 20 0s12 8 20 0 12 8 20 0 12 8 21 0" />
  </motion.svg>
);

/** Soft dot-pair accent — staggered gentle bounce */
export const Dots: React.FC<ShapeProps> = ({
  size = 26,
  color = "var(--lp-green-mid)",
  className = "",
  style,
  animate = true,
}) => (
  <motion.svg
    aria-hidden="true"
    width={size}
    height={size}
    viewBox="0 0 26 26"
    className={className}
    style={style}
    fill={color}
    initial={false}
  >
    <motion.circle
      cx="6"
      cy="6"
      r="3"
      animate={animate ? { y: [0, -3, 0], opacity: [0.7, 1, 0.7] } : undefined}
      transition={{
        duration: 2.8,
        repeat: Infinity,
        ease: "easeInOut",
        delay: 0,
      }}
    />
    <motion.circle
      cx="20"
      cy="13"
      r="3"
      animate={
        animate ? { y: [0, -3.5, 0], opacity: [0.7, 1, 0.7] } : undefined
      }
      transition={{
        duration: 3.1,
        repeat: Infinity,
        ease: "easeInOut",
        delay: 0.35,
      }}
    />
    <motion.circle
      cx="8"
      cy="20"
      r="3"
      animate={
        animate ? { y: [0, -2.5, 0], opacity: [0.7, 1, 0.7] } : undefined
      }
      transition={{
        duration: 2.6,
        repeat: Infinity,
        ease: "easeInOut",
        delay: 0.7,
      }}
    />
  </motion.svg>
);
