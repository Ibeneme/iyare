import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Check, Play } from "lucide-react";
import {
  HighlightWord,
  NotebookCard,
  PersonAvatar,
  Plus,
  Ring,
  SectionLabel,
  SkeletonLines,
  Sparkle,
} from "../Shared/index";
import { PATHS } from "../../routes/paths";

const easeOut = [0.22, 1, 0.36, 1] as const;

const rise = (delay = 0) => ({
  initial: { opacity: 0, y: 28 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.7, ease: easeOut },
});

const cardRise = (delay = 0) => ({
  initial: { opacity: 0, y: 36, scale: 0.96 },
  animate: { opacity: 1, y: 0, scale: 1 },
  transition: { delay, duration: 0.75, ease: easeOut },
});

const float = (duration = 5, delay = 0) => ({
  y: [0, -10, 0],
  transition: {
    duration,
    delay,
    repeat: Infinity,
    ease: "easeInOut" as const,
  },
});

const listItem = {
  initial: { opacity: 0, x: -8 },
  animate: { opacity: 1, x: 0 },
};

const HeroSection: React.FC = () => {
  const navigate = useNavigate();

  return (
    <section
      aria-labelledby="hero-title"
      className="relative overflow-hidden pt-16 sm:pt-20 pb-16"
    >
      {/* Floating decoration */}
      <motion.div
        className="absolute left-[8%] top-[34%] hidden md:block"
        animate={float(5.5, 0.2)}
      >
        <Sparkle size={34} />
      </motion.div>

      <motion.div
        className="absolute right-[10%] top-[10%] hidden md:block"
        animate={float(6.5, 0.8)}
      >
        <Sparkle size={30} color="var(--lp-green-mid)" />
      </motion.div>

      <motion.div
        className="absolute left-[18%] top-[56%] hidden lg:block"
        animate={float(7, 1.1)}
      >
        <Ring />
      </motion.div>

      <motion.div
        className="absolute right-[7%] top-[26%] hidden lg:block"
        animate={float(5.8, 0.4)}
      >
        <Ring size={26} color="var(--lp-yellow)" />
      </motion.div>

      <motion.div
        className="absolute right-[22%] top-[58%] hidden lg:block"
        animate={float(6.2, 0.6)}
      >
        <Plus />
      </motion.div>

      <div className="lp-container relative text-center">
        <motion.div {...rise(0)}>
          <SectionLabel>Live online lessons for Nigerian families</SectionLabel>
        </motion.div>

        <motion.h1
          id="hero-title"
          {...rise(0.12)}
          className="lp-h1 mt-6 mx-auto max-w-4xl"
        >
          Learn big things,
          <br />
          without ever <HighlightWord>leaving home.</HighlightWord>
        </motion.h1>

        <motion.p {...rise(0.22)} className="lp-lead mt-6 mx-auto max-w-xl">
          Yare Height brings qualified teachers, live classes, homework and
          progress reports into one friendly place, so every child can keep
          growing at their own pace.
        </motion.p>

        <motion.div
          {...rise(0.32)}
          className="mt-8 mb-12 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <motion.button
            onClick={() => navigate(PATHS.register)}
            className="lp-btn lp-btn--dark lp-btn--lg"
            whileHover={{ scale: 1.03, y: -1 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 22 }}
          >
            Start learning
          </motion.button>

          <motion.a
            href="#how-it-works"
            className="inline-flex items-center gap-3 text-sm font-semibold text-[var(--lp-ink)]"
            whileHover={{ x: 2 }}
          >
            <span className="w-10 h-10 grid place-items-center rounded-full bg-[var(--lp-surface)] shadow-[0_6px_18px_-6px_rgba(45,55,25,.35)]">
              <Play size={14} fill="currentColor" />
            </span>
            See how it works
          </motion.a>
        </motion.div>
      </div>

      {/* Notebook cards */}
      <div className="lp-container mt-14 sm:mt-16">
        <div className="grid gap-5 md:gap-6 md:grid-cols-[1.35fr_1fr_1.15fr]">
          {/* Today’s Classes */}
          <motion.div
            {...cardRise(0.42)}
            whileHover={{ y: -6, transition: { duration: 0.3 } }}
          >
            <NotebookCard
              tone="green"
              title={
                <>
                  Today’s
                  <br />
                  Classes
                </>
              }
            >
              <div className="flex items-center gap-3">
                <PersonAvatar variant={2} size={58} />
                <SkeletonLines widths={[88, 62]} className="flex-1" />
              </div>

              <ul className="mt-6 space-y-3 text-base font-medium">
                {[
                  { label: "Maths · 10:00 am", delay: 0.55 },
                  { label: "English · 12:30 pm", delay: 0.65 },
                ].map((item) => (
                  <motion.li
                    key={item.label}
                    variants={listItem}
                    initial="initial"
                    animate="animate"
                    transition={{
                      delay: item.delay,
                      duration: 0.45,
                      ease: easeOut,
                    }}
                    className="flex items-center gap-2"
                  >
                    <span className="w-2 h-2 rounded-full bg-white/60" />
                    {item.label}
                  </motion.li>
                ))}
              </ul>

              <SkeletonLines widths={[92, 70]} className="mt-6" />
            </NotebookCard>
          </motion.div>

          {/* Homework Tracker */}
          <motion.div
            {...cardRise(0.52)}
            whileHover={{ y: -6, transition: { duration: 0.3 } }}
          >
            <NotebookCard
              tone="yellow"
              title={
                <>
                  Homework
                  <br />
                  Tracker
                </>
              }
              rings
            >
              <ul className="space-y-4">
                {[true, true, false, false].map((done, i) => (
                  <motion.li
                    key={i}
                    variants={listItem}
                    initial="initial"
                    animate="animate"
                    transition={{
                      delay: 0.62 + i * 0.08,
                      duration: 0.4,
                      ease: easeOut,
                    }}
                    className="flex items-center gap-3"
                  >
                    <span
                      className={`w-6 h-6 rounded-full grid place-items-center border-2 ${
                        done
                          ? "bg-[var(--lp-green-deep)] border-[var(--lp-green-deep)] text-white"
                          : "border-[var(--lp-green-deep)]/40"
                      }`}
                    >
                      {done && <Check size={13} strokeWidth={3} />}
                    </span>
                    <SkeletonLines
                      widths={[i % 2 ? 62 : 80]}
                      className="flex-1"
                    />
                  </motion.li>
                ))}
              </ul>
            </NotebookCard>
          </motion.div>

          {/* Parent Chat */}
          <motion.div
            {...cardRise(0.62)}
            whileHover={{ y: -6, transition: { duration: 0.3 } }}
          >
            <NotebookCard
              tone="deep"
              title={
                <>
                  Parent
                  <br />
                  Chat
                </>
              }
              rings
            >
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.75, duration: 0.5, ease: easeOut }}
                className="flex items-start gap-3"
              >
                <PersonAvatar variant={4} size={44} />
                <div className="rounded-2xl rounded-tl-sm bg-white/12 px-4 py-3 text-sm flex-1">
                  Great progress in reading today!
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9, duration: 0.5, ease: easeOut }}
                className="flex items-start gap-3 mt-4 flex-row-reverse"
              >
                <PersonAvatar variant={1} size={44} />
                <div
                  className="rounded-2xl rounded-tr-sm px-4 py-3 text-sm flex-1"
                  style={{
                    background: "var(--lp-yellow)",
                    color: "var(--lp-on-yellow)",
                  }}
                >
                  Thank you, teacher!
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.05, duration: 0.45, ease: easeOut }}
                className="flex items-start gap-3 mt-4"
              >
                <PersonAvatar variant={4} size={44} />
                <SkeletonLines widths={[78, 50]} className="flex-1 pt-3" />
              </motion.div>
            </NotebookCard>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
