import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AllPrices } from "../../store/features/settings/settings.slice";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../store/index";
import PricingHeroSection from "./PricingHeroSection";
import PlanCard from "./PlanCard";
import PricingLoadingScreen from "./PricingLoadingScreen";
import PricingTrustNote from "./PricingTrustNote";
import { PLAN_FEATURES } from "./planCatalog";

interface Plan {
  name: string;
  duration: string;
  months: number;
  original: number;
  price: number;
  savings: number;
  popular?: boolean;
  features: string[];
  planId: string;
}

const PricingPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();

  const [isNigeria, setIsNigeria] = useState<boolean | null>(null);
  const [prices, setPrices] = useState<{
    local: number;
    international: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  const { studentIds, parentId } = location.state || {};

  // Fetch prices
  useEffect(() => {
    dispatch(AllPrices())
      .unwrap()
      .then((res) => {
        setPrices({
          local: res.data.localPrice,
          international: res.data.internationalPrice,
        });
      })
      .catch(() => {
        setPrices({ local: 50000, international: 100000 });
      });
  }, [dispatch]);

  // Location detection
  useEffect(() => {
    const detectLocation = async () => {
      try {
        const res = await fetch("https://geolocation-db.com/json/");
        const data = await res.json();
        const isNG =
          data.country_code === "NG" ||
          data.country_name?.toLowerCase().includes("nigeria");
        setIsNigeria(isNG);
      } catch {
        setIsNigeria(true);
      } finally {
        setLoading(false);
      }
    };
    detectLocation();
  }, []);

  // Base price per month (local or international)
  const basePricePerMonth = prices
    ? isNigeria === false
      ? prices.international
      : prices.local
    : 50000;

  // Price = months × base price × discount
  const plans: Plan[] = [
    {
      name: "1 Month",
      duration: "30 days access",
      months: 1,
      discount: 0,
      popular: false,
      features: PLAN_FEATURES.monthly,
      planId: "monthly",
    },
    {
      name: "3 Months",
      duration: "90 days access",
      months: 3,
      discount: 0.033,
      popular: true,
      features: PLAN_FEATURES.quarterly,
      planId: "quarterly",
    },
    {
      name: "6 Months",
      duration: "180 days access",
      months: 6,
      discount: 0.067,
      popular: false,
      features: PLAN_FEATURES.semiannual,
      planId: "semiannual",
    },
  ].map((plan) => {
    const original = basePricePerMonth * plan.months;
    const price = Math.floor(original * (1 - plan.discount));
    const savings = original - price;

    return {
      ...plan,
      original,
      price,
      savings,
    };
  });

  const handleButtonClick = (plan: Plan) => {
    if (Array.isArray(studentIds) && studentIds.length > 0) {
      const totalAmount = plan.price * studentIds.length;
      navigate("/plans/payment", {
        state: { parentId, studentIds, planId: plan.planId, totalAmount },
      });
    } else {
      navigate("/register");
    }
  };

  const formatPrice = (amount: number) =>
    new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(amount);

  if (loading || !prices) {
    return <PricingLoadingScreen message="Finding the best prices for you…" />;
  }

  return (
    <main className="lp-section overflow-hidden">
      <div className="lp-container">
        <PricingHeroSection
          label="Simple, fair pricing"
          before="Pick the plan that"
          highlight="fits your family."
          subtitle={
            isNigeria
              ? "Quality lessons at a price Nigerian families can plan around."
              : "Premium lessons with the same care, wherever you are in the world."
          }
          regionBadge={isNigeria === null ? null : isNigeria ? "Showing Nigerian prices" : "Showing international prices"}
        />

        <div className="mt-16 grid gap-6 md:grid-cols-3 md:items-stretch pt-4">
          {plans.map((plan, index) => (
            <PlanCard
              key={plan.planId}
              index={index}
              name={plan.name}
              duration={plan.duration}
              priceText={formatPrice(plan.price)}
              originalText={plan.savings > 0 ? formatPrice(plan.original) : undefined}
              savingsText={plan.savings > 0 ? `₦${plan.savings.toLocaleString()}` : undefined}
              priceNote={plan.savings > 0 ? undefined : isNigeria === false ? "one-time payment" : "per student"}
              features={plan.features}
              popular={plan.popular}
              buttonLabel={studentIds?.length > 0 ? "Pay now" : "Get started"}
              onSelect={() => handleButtonClick(plan)}
            />
          ))}
        </div>

        <PricingTrustNote>Payments are processed securely by Paystack</PricingTrustNote>
      </div>
    </main>
  );
};

export default PricingPage;
