import { useNavigate } from "react-router-dom";
import { PATHS, buildPath } from "../../../routes/paths";
import React, { useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  Edit2,
  Trash2,
  BookOpen,
  Loader2,
  X,
  User,
  // Check,
  Lock,
  Layers,
  Search,
  AlertTriangle,
  ChevronRight,
} from "lucide-react";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../../store/index";
import {
  fetchGrades,
  createGrade,
  updateGrade,
  deleteGrade,
  fetchSubjectsByGrade,
} from "../../../store/features/grades/grades.slice";
import { useToast } from "../../../contexts/ToastContext";
import { getUserType } from "../../../utils/userType";

type ToastType = "success" | "error" | "info" | "warning";

export interface ToastContextType {
  addToast: (type: ToastType, message: string) => void;
}

// // PREMIUM COLOR PALETTE
// const ACCENT_COLOR = "#fbbf24"; // Amber/Gold

interface Grade {
  _id: string;
  title: string;
  description?: string;
}

interface Subject {
  _id: string;
  name: string;
  code: string;
  description?: string;
  teachers?: { firstName: string; lastName: string }[];
}

const GradesManagement: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { addToast } = useToast();
  const userType = getUserType();
  const isAdmin = userType === "admin";

  const [grades, setGrades] = useState<Grade[]>([]);
  const [subjectsCache, setSubjectsCache] = useState<Record<string, Subject[]>>(
    {}
  );
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [subjectSearch, setSubjectSearch] = useState("");

  const [selectedGrade, setSelectedGrade] = useState<Grade | null>(null);
  const [formData, setFormData] = useState({ title: "", description: "" });

  const navigate = useNavigate();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const result = await dispatch(fetchGrades()).unwrap();
        setGrades(result || []);
      } catch {
        addToast("error", "Failed to load grades");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [dispatch]);

  const loadSubjects = async (gradeId: string) => {
    if (subjectsCache[gradeId]) return;
    try {
      const result = await dispatch(fetchSubjectsByGrade(gradeId)).unwrap();
      setSubjectsCache((p) => ({ ...p, [gradeId]: result || [] }));
    } catch {
      addToast("error", "Failed to load subjects");
    }
  };

  const openView = async (grade: Grade) => {
    setSelectedGrade(grade);
    setSubjectSearch("");
    await loadSubjects(grade._id);
    setIsViewOpen(true);
  };

  const openEdit = (grade: Grade) => {
    setSelectedGrade(grade);
    setFormData({ title: grade.title, description: grade.description || "" });
    setIsEditOpen(true);
  };

  const openDelete = (grade: Grade) => {
    setSelectedGrade(grade);
    setIsDeleteOpen(true);
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return addToast("error", "Title is required");
    try {
      const newGrade = await dispatch(createGrade(formData)).unwrap();
      setGrades((p) => [...p, newGrade]);
      addToast("success", "Grade created!");
      setIsAddOpen(false);
      setFormData({ title: "", description: "" });
    } catch {
      addToast("error", "Failed to create grade");
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGrade || !formData.title.trim()) return;
    try {
      const updated = await dispatch(
        updateGrade({ id: selectedGrade._id, data: formData })
      ).unwrap();
      setGrades((p) =>
        p.map((g) => (g._id === selectedGrade._id ? updated : g))
      );
      addToast("success", "Grade updated!");
      setIsEditOpen(false);
    } catch {
      addToast("error", "Failed to update grade");
    }
  };

  const handleDelete = async () => {
    if (!selectedGrade) return;
    try {
      await dispatch(deleteGrade(selectedGrade._id)).unwrap();
      setGrades((p) => p.filter((g) => g._id !== selectedGrade._id));
      setSubjectsCache((p) => {
        const { [selectedGrade._id]: _, ...rest } = p;
        return rest;
      });
      addToast("success", "Grade deleted");
      setIsDeleteOpen(false);
      setSelectedGrade(null);
    } catch {
      addToast("error", "Failed to delete grade");
    }
  };

  const filteredGrades = useMemo(() => {
    if (!searchQuery.trim()) return grades;
    const q = searchQuery.toLowerCase();
    return grades.filter(
      (g) =>
        g.title.toLowerCase().includes(q) ||
        g.description?.toLowerCase().includes(q)
    );
  }, [grades, searchQuery]);

  const currentSubjects = selectedGrade
    ? subjectsCache[selectedGrade._id] || []
    : [];
  const filteredSubjects = useMemo(() => {
    if (!subjectSearch.trim()) return currentSubjects;
    const q = subjectSearch.toLowerCase();
    return currentSubjects.filter(
      (s) =>
        s.name.toLowerCase().includes(q) || s.code.toLowerCase().includes(q)
    );
  }, [currentSubjects, subjectSearch]);

  const getSubjectCount = (gradeId: string) =>
    subjectsCache[gradeId]?.length || 0;

  return (
    <div className="page">
      <motion.header
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="page-header"
      >
        <div>
          <h1 className="page-title">Grades</h1>
          <p className="page-subtitle">
            {isAdmin ? "Organise and manage academic levels." : "Browse academic levels and their subjects."}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => navigate(PATHS.gradeNew)}
            className="btn-primary"
          >
            <Plus className="w-4 h-4" /> Add level
          </button>
        )}
      </motion.header>

      <section className="card p-5 sm:p-6 grid grid-cols-2 gap-4">
        <div>
          <p className="stat-label">Levels</p>
          <p className="stat-value mt-1">{grades.length}</p>
        </div>
        <div>
          <p className="stat-label">Showing</p>
          <p className="stat-value mt-1">{filteredGrades.length}</p>
        </div>
      </section>

      <div className="relative w-full max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-subtle pointer-events-none" />
        <input
          type="text"
          placeholder="Search levels"
          aria-label="Search levels"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-input bg-card"
        />
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-28">
          <Loader2 className="w-10 h-10 animate-spin text-primary mb-3" />
          <p className="text-sm text-muted">Loading levels…</p>
        </div>
      ) : filteredGrades.length === 0 ? (
        <div className="card text-center py-20">
          <BookOpen className="w-12 h-12 text-subtle mx-auto mb-3" />
          <h3 className="section-title">No levels found</h3>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {filteredGrades.map((grade, i) => (
              <motion.div
                key={grade._id}
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.04 }}
                className="card p-5 sm:p-6 hover:shadow-elevated transition-shadow duration-300 group flex flex-col"
              >
                <div className="mb-5 flex justify-between items-start">
                  <span className="w-11 h-11 rounded-2xl bg-surface text-primary grid place-items-center">
                    <Layers size={20} />
                  </span>

                  {isAdmin ? (
                    <div className="flex gap-1 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => navigate(buildPath(PATHS.gradeEdit, { id: grade._id }))} aria-label="Edit level" className="btn-icon w-8 h-8">
                        <Edit2 size={14} />
                      </button>
                      <button onClick={() => openDelete(grade)} aria-label="Delete level" className="btn-icon w-8 h-8 text-[var(--color-danger)]">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ) : (
                    <Lock size={14} className="text-subtle" />
                  )}
                </div>

                <h3 className="text-lg font-semibold tracking-tight text-primary mb-1">{grade.title}</h3>
                <p className="text-muted text-sm line-clamp-2 flex-grow">
                  {grade.description || "No description provided for this level."}
                </p>

                <div className="mt-6 pt-4 divider flex items-center justify-between">
                  <span className="badge-gray">{getSubjectCount(grade._id)} subjects</span>
                  <button
                    onClick={() => openView(grade)}
                    className="text-sm font-medium text-primary flex items-center gap-1 hover:gap-2 transition-all"
                  >
                    Details <ChevronRight size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* MODALS REFACTORED TO PREMIUM STYLE */}
      <Modal
        title="Add Level"
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
      >
        <form onSubmit={handleCreate} className="space-y-6">
          <Input
            label="Level Title"
            value={formData.title}
            onChange={(e: any) =>
              setFormData((p) => ({ ...p, title: e.target.value }))
            }
            required
            placeholder="e.g. Grade 10"
          />
          <Textarea
            label="Description"
            rows={3}
            value={formData.description}
            onChange={(e: any) =>
              setFormData((p) => ({ ...p, description: e.target.value }))
            }
            placeholder="Briefly describe this academic tier..."
          />
          <div className="flex gap-3">
            <button
              type="submit"
              className="btn-primary flex-1"
            >
              Create Level
            </button>
            <button
              type="button"
              onClick={() => setIsAddOpen(false)}
              className="btn-secondary flex-1"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        title="Edit Level"
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
      >
        <form onSubmit={handleUpdate} className="space-y-6">
          <Input
            label="Level Title"
            value={formData.title}
            onChange={(e: any) =>
              setFormData((p) => ({ ...p, title: e.target.value }))
            }
            required
          />
          <Textarea
            label="Description"
            rows={3}
            value={formData.description}
            onChange={(e: any) =>
              setFormData((p) => ({ ...p, description: e.target.value }))
            }
          />
          <div className="flex gap-3">
            <button
              type="submit"
              className="btn-primary flex-1"
            >
              Save Changes
            </button>
            <button
              type="button"
              onClick={() => setIsEditOpen(false)}
              className="btn-secondary flex-1"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        title="Delete Confirmation"
        isOpen={isDeleteOpen}
        onClose={() => setIsDeleteOpen(false)}
      >
        <div className="text-center py-6">
          <div className="w-14 h-14 bg-[var(--color-danger-bg)] rounded-full flex items-center justify-center mx-auto mb-5">
            <AlertTriangle className="w-6 h-6 text-[var(--color-danger)]" />
          </div>
          <h3 className="text-xl font-semibold text-primary">
            Delete {selectedGrade?.title}?
          </h3>
          <p className="text-muted text-sm mt-1.5">
            This is permanent. All associated data will be removed.
          </p>
          <div className="flex gap-3 mt-8">
            <button
              onClick={handleDelete}
              className="btn-danger flex-1"
            >
              Yes, delete
            </button>
            <button
              onClick={() => setIsDeleteOpen(false)}
              className="btn-secondary flex-1"
            >
              Keep it
            </button>
          </div>
        </div>
      </Modal>

      <Modal
        title={`Subjects — ${selectedGrade?.title || ""}`}
        isOpen={isViewOpen}
        onClose={() => setIsViewOpen(false)}
      >
        <div className="space-y-6">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted" />
            <input
              type="text"
              placeholder="Search subjects..."
              value={subjectSearch}
              onChange={(e) => setSubjectSearch(e.target.value)}
              className="search-input"
            />
          </div>

          <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
            {filteredSubjects.length === 0 ? (
              <p className="text-center text-muted text-sm py-10 bg-surface rounded-3xl">
                No subjects yet.
              </p>
            ) : (
              filteredSubjects.map((subject) => (
                <div
                  key={subject._id}
                  className="bg-surface rounded-2xl p-4"
                >
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-semibold text-primary">
                      {subject.name}
                    </h4>
                    <span className="badge-gray">
                      {subject.code}
                    </span>
                  </div>
                  {subject.description && (
                    <p className="text-muted text-xs leading-relaxed">
                      {subject.description}
                    </p>
                  )}
                  <div className="mt-3 flex items-center gap-2 text-xs text-muted">
                    <User size={12} />
                    {subject.teachers?.length
                      ? subject.teachers
                          .map((t) => `${t.firstName} ${t.lastName}`)
                          .join(", ")
                      : "Unassigned"}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </Modal>
    </div>
  );
};

// HELPER COMPONENTS
const Modal = ({ title, isOpen, onClose, children }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="card-elevated rounded-t-[1.75rem] sm:rounded-[1.75rem] w-full max-w-lg max-h-[90vh] overflow-y-auto flex flex-col"
      >
        <div className="px-6 sm:px-8 pt-6 pb-2 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-primary tracking-tight">
            {title}
          </h2>
          <button
            onClick={onClose}
            className="btn-icon w-9 h-9" aria-label="Close"
          >
            <X size={16} />
          </button>
        </div>
        <div className="p-6 sm:p-8 pt-4">{children}</div>
      </motion.div>
    </div>
  );
};

const Input = ({ label, ...props }: any) => (
  <div className="space-y-1.5">
    <label className="form-label">
      {label}
    </label>
    <input
      className="form-input"
      {...props}
    />
  </div>
);

const Textarea = ({ label, ...props }: any) => (
  <div className="space-y-1.5">
    <label className="form-label">
      {label}
    </label>
    <textarea
      className="form-input resize-none"
      {...props}
    />
  </div>
);

export default GradesManagement;
