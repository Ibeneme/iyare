import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { fetchReports } from "../../../store/features/settings/settings.slice";
import { AnimatePresence, motion } from "framer-motion";
import {
  Loader2,
  Mail,
  FileText,
  Calendar,
  ChevronRight,
  AlertCircle,
  Inbox,
} from "lucide-react";

const Reports: React.FC = () => {
  const dispatch = useDispatch();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  useEffect(() => {
    setLoading(true);
    dispatch(fetchReports() as any)
      .unwrap()
      .then((data: any) => {
        setReports(data);
        setLoading(false);
      })
      .catch((err: any) => {
        console.log(err);
        setError("Failed to synchronize reports. Please try again.");
        setLoading(false);
      });
  }, [dispatch]);

  const handleOpenModal = (report: any) => {
    setSelectedReport(report);
    setIsModalOpen(true);
  };

  return (
    <div className="page">
      {loading ? (
        <div className="fixed inset-0 flex flex-col items-center justify-center bg-[var(--color-card)] backdrop-blur-md z-[100]">
          <Loader2 className="w-16 h-16 animate-spin text-[var(--color-primary)]" />
          <p className="mt-6 text-[10px] font-semibold  tracking-[0.4em] text-[var(--color-primary)]">
            Fetching Intelligence...
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Header */}
          <header className="page-header">
            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="page-title">Reports</h1>
                <span className="badge-blue">{reports.length} received</span>
              </div>
              <p className="page-subtitle max-w-xl">
                Feedback and issues submitted by users. Open any entry to read it and reply.
              </p>
            </div>
          </header>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-5 bg-[var(--color-danger-bg)] border border-[var(--color-card-border)] rounded-2xl flex items-center gap-3"
            >
              <AlertCircle className="text-[var(--color-danger)]" size={20} />
              <p className="text-xs font-semibold  tracking-tight text-[var(--color-danger)]">
                {error}
              </p>
            </motion.div>
          )}

          {/* Reports Content */}
          {reports.length === 0 ? (
            <div className="text-center py-24 bg-[var(--color-card)] rounded-3xl border border-[var(--color-card-border)] shadow-[var(--shadow-card)]">
              <div className="w-20 h-20 bg-[var(--color-surface)] rounded-full flex items-center justify-center mx-auto mb-6">
                <Inbox size={32} className="text-[var(--color-subtle)]" />
              </div>
              <h2 className="text-xl font-semibold text-[var(--color-primary)] tracking-tight">
                No Reports Found
              </h2>
              <p className="text-[var(--color-muted)] font-semibold text-sm  tracking-tight mt-2">
                Database is currently empty
              </p>
            </div>
          ) : (
            <div className="bg-[var(--color-card)] rounded-3xl border border-[var(--color-card-border)] shadow-[var(--shadow-card)] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th className="">
                        Sender Email
                      </th>
                      <th className="">
                        Subject Title
                      </th>
                      <th className="">
                        Preview
                      </th>
                      <th className="">
                        Timestamp
                      </th>
                      <th className="text-right">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {reports.map((report: any, index: number) => (
                      <tr
                        key={report._id || index}
                        onClick={() => handleOpenModal(report)}
                        className="cursor-pointer"
                      >
                        <td>
                          <span className="font-semibold text-[var(--color-primary)] text-sm tracking-tight">
                            {report.email}
                          </span>
                        </td>
                        <td>
                          <span className="badge-yellow">
                            {report.title}
                          </span>
                        </td>
                        <td>
                          <p className="text-[var(--color-muted)] font-semibold text-sm truncate max-w-[200px]">
                            {report.description}
                          </p>
                        </td>
                        <td>
                          <div className="flex items-center gap-2 text-[var(--color-muted)] font-semibold text-[10px]  tracking-tight">
                            <Calendar size={12} />
                            {new Date(report.createdAt).toLocaleDateString()}
                          </div>
                        </td>
                        <td>
                          <div className="inline-flex p-3 rounded-xl text-[var(--color-primary)] group-hover:bg-yellow-400 transition-all">
                            <ChevronRight size={18} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Modal System */}
          <AnimatePresence>
            {isModalOpen && selectedReport && (
              <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setIsModalOpen(false)}
                  className="fixed inset-0 bg-[var(--color-brand)] backdrop-blur-sm"
                />
                <motion.div
                  initial={{ scale: 0.95, y: 30 }}
                  animate={{ scale: 1, y: 0 }}
                  exit={{ scale: 0.95, y: 30 }}
                  className="relative bg-[var(--color-card)] rounded-3xl shadow-[var(--shadow-elevated)] w-full max-w-2xl overflow-hidden flex flex-col"
                >
                  {/* Modal Header */}
                  <div className="bg-[#1b2030] p-10 md:p-12 text-white">
                    <div className="flex justify-between items-start mb-6">
                      <div className="space-y-2">
                        <p className="text-yellow-400 font-semibold text-[10px]  tracking-[0.3em]">
                          Official Report Detail
                        </p>
                        <h3 className="text-3xl font-semibold tracking-tight leading-none">
                          {selectedReport.title}
                        </h3>
                      </div>
                      <div className="w-12 h-12 bg-[var(--color-card)] rounded-2xl flex items-center justify-center">
                        <FileText className="text-yellow-400" />
                      </div>
                    </div>
                    <div className="flex items-center gap-3 px-4 py-2 bg-[var(--color-card)] rounded-xl border border-white/10 w-fit">
                      <Mail size={14} className="text-yellow-400" />
                      <span className="text-sm font-semibold text-white/70">
                        {selectedReport.email}
                      </span>
                    </div>
                  </div>

                  {/* Modal Body */}
                  <div className="p-10 md:p-12 space-y-8">
                    <div className="space-y-4">
                      <h4 className="text-[10px] font-semibold text-[var(--color-muted)]  tracking-[0.2em] flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full" />
                        Report Narrative
                      </h4>
                      <div className="bg-[var(--color-surface)] p-8 rounded-3xl border border-[var(--color-card-border)] max-h-72 overflow-y-auto custom-scrollbar">
                        <p className="text-[var(--color-primary)] font-semibold leading-relaxed whitespace-pre-wrap">
                          {selectedReport.description}
                        </p>
                      </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="flex flex-col md:flex-row gap-4 pt-6">
                      <a
                        href={`mailto:${
                          selectedReport.email
                        }?subject=Formal Response: ${encodeURIComponent(
                          selectedReport.title
                        )}`}
                        className="flex-[2] inline-flex items-center justify-center gap-3 bg-[#1b2030] text-white py-6 rounded-3xl font-semibold text-xs  tracking-[0.2em] shadow-[var(--shadow-elevated)] hover:bg-[var(--color-brand-hover)] transition-all"
                      >
                        <Mail size={18} />
                        Initiate Email Response
                      </a>
                      <button
                        onClick={() => setIsModalOpen(false)}
                        className="flex-1 bg-[var(--color-surface-alt)] text-[var(--color-muted)] py-6 rounded-3xl font-semibold text-xs  tracking-tight hover:bg-[var(--color-surface-alt)] transition-all"
                      >
                        Dismiss
                      </button>
                    </div>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default Reports;
