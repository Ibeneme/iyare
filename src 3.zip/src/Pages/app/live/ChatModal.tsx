import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send } from "lucide-react";

export interface ChatMessage {
  id: string;
  username: string;
  message: string;
  isMe?: boolean;
  image?: string;
}

interface Props {
  username: string;
  chatMessages: ChatMessage[];
  sendChatMessage: () => void;
  chatInput: string;
  setChatInput: (val: string) => void;
}

export default function ChatModal({
  username,
  chatMessages,
  sendChatMessage,
  chatInput,
  setChatInput,
}: Props) {
  const [isOpen, setIsOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, isOpen]);

  const getFirstName = (name: string) => name.trim().split(" ")[0];

  return (
    <>
      {!isOpen && (
        <motion.button
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setIsOpen(true)}
          aria-label="Open class chat"
          className="fixed bottom-6 right-6 h-12 w-12 grid place-items-center rounded-full bg-white text-neutral-900 z-50 shadow-lg"
        >
          <MessageCircle size={22} />
        </motion.button>
      )}

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.97 }}
            transition={{ type: "spring", damping: 26, stiffness: 300 }}
            className="fixed z-50 right-3 bottom-3 sm:right-5 sm:bottom-5 top-3 sm:top-auto w-[calc(100vw-1.5rem)] sm:w-96 sm:h-[34rem] max-h-[calc(100vh-1.5rem)] flex flex-col rounded-[1.75rem] bg-neutral-900/95 backdrop-blur-xl text-white shadow-2xl overflow-hidden"
          >
            <div className="px-5 py-4 flex justify-between items-center">
              <h2 className="text-base font-semibold">Class chat</h2>
              <button
                onClick={() => setIsOpen(false)}
                aria-label="Close chat"
                className="h-8 w-8 grid place-items-center rounded-full bg-white/10 hover:bg-white/20 transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-3">
              {chatMessages.length === 0 ? (
                <p className="text-center text-sm text-white/50 mt-10">
                  Start the conversation!
                </p>
              ) : (
                chatMessages.map((msg, idx) => {
                  const isMe = msg.username === username;
                  return (
                    <motion.div
                      key={msg.id || idx}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[85%] px-4 py-2 rounded-2xl ${
                          isMe
                            ? "bg-white text-neutral-900 rounded-br-md"
                            : "bg-white/10 text-white rounded-bl-md"
                        }`}
                      >
                        {!isMe && (
                          <p className="text-xs font-semibold text-[#FFD000] mb-0.5">
                            {getFirstName(msg.username)}
                          </p>
                        )}
                        <p className="text-sm leading-relaxed break-words">{msg.message}</p>
                      </div>
                    </motion.div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-3">
              <div className="flex gap-2 items-center bg-white/10 rounded-full pl-4 pr-1.5 py-1.5">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendChatMessage()}
                  placeholder="Type a message..."
                  className="flex-1 bg-transparent text-white placeholder:text-white/40 focus:outline-none text-sm"
                />
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={sendChatMessage}
                  aria-label="Send message"
                  className="h-9 w-9 grid place-items-center rounded-full bg-white text-neutral-900 flex-shrink-0"
                >
                  <Send size={16} />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
