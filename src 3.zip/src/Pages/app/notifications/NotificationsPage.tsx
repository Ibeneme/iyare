import { getCookie } from "../../../utils/cookies";
import Select from "../../../components/ui/Select";
import { useEffect, useState, useCallback, useMemo } from "react";
import {
  Loader2,
  X,
  Check,
  Bell,
  CheckCheck,
  Clock,
  ChevronRight,
  Info,
  BookOpen,
  Calendar,
  Search,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom"; 
import { AppDispatch, RootState } from "../../../store/index";
import {
  fetchNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  NotificationModel,
} from "../../../store/features/notifications/notifications.slice";

export default function NotificationsManager() {
  
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate(); // ← added
  const { notifications, unreadCount, loading } = useSelector(
    (state: RootState) => state.notifications
  );

  const [search, setSearch] = useState("");
  const [selectedType, setSelectedType] = useState<string>("");
  const [selectedNotification, setSelectedNotification] =
    useState<NotificationModel | null>(null);
  const [isMobileDetailOpen, setIsMobileDetailOpen] = useState(false);

  /* ---------- Load Notifications ---------- */
  const loadNotifications = useCallback(() => {
    dispatch(fetchNotifications())
      .unwrap()
      .catch((err) => {
        const msg = err || "Failed to load notifications";
        toast.error(msg);
      });
  }, [dispatch]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  /* ---------- Handlers ---------- */
  const handleSelectNotification = (notification: NotificationModel) => {
    setSelectedNotification(notification);
    setIsMobileDetailOpen(true);
    if (!notification.isRead) {
      dispatch(markNotificationAsRead(notification._id))
        .unwrap()
        .catch(() => {});
    }
  };

  const handleCloseMobileDetail = () => {
    setIsMobileDetailOpen(false);
  };

  const handleMarkAllRead = async () => {
    try {
      await dispatch(markAllNotificationsAsRead()).unwrap();
      toast.success("All notifications marked as read!");
    } catch (err: any) {
      toast.error(err || "Failed to update notifications");
    }
  };

  // Navigate to subject (passes subjectName in location.state)
  const goToSubject = (subjectId: string, subjectName?: string) => {
    navigate(`/app/subjects/${subjectId}`, {
      state: { subjectName: subjectName || undefined },
    });
  };

  // Navigate to class (for class_schedule notifications)
  const goToClass = (classId: string) => {
    navigate(`/classes/${classId}`);
  };

  const filteredNotifications = useMemo(() => {
    let result = notifications;
    if (selectedType) {
      result = result.filter((n: any) => n.type === selectedType);
    }
    const term = search?.trim()?.toLowerCase();
    if (term) {
      result = result.filter((n: any) => {
        const title = n.title?.toLowerCase() ?? "";
        const description = n.description?.toLowerCase() ?? "";
        const typeStr = n.type?.toLowerCase() ?? "";
        return (
          title.includes(term) ||
          description.includes(term) ||
          typeStr.includes(term)
        );
      });
    }
    return result;
  }, [notifications, selectedType, search]);

  // Auto-select first notification only on desktop (lg+)
  useEffect(() => {
    const isDesktop = window.matchMedia("(min-width: 1024px)").matches;
    if (
      isDesktop &&
      filteredNotifications.length > 0 &&
      !selectedNotification
    ) {
      setSelectedNotification(filteredNotifications[0]);
    }
  }, [filteredNotifications, selectedNotification]);

  // Close mobile overlay when resizing to desktop
  useEffect(() => {
    const media = window.matchMedia("(min-width: 1024px)");
    const handler = (e: MediaQueryListEvent) => {
      if (e.matches) setIsMobileDetailOpen(false);
    };
    media.addEventListener("change", handler);
    return () => media.removeEventListener("change", handler);
  }, []);

  const resetFilters = () => {
    setSearch("");
    setSelectedType("");
  };

  const getEmptyMessage = () => {
    if (search && selectedType)
      return "No notifications found matching your search and type filter.";
    if (search) return "No notifications match your search.";
    if (selectedType) return "No notifications found for this category.";
    return "Your inbox is completely clear.";
  };

  const availableTypes = useMemo(() => {
    const typesSet = new Set<string>();
    notifications.forEach((n: any) => {
      if (n.type) typesSet.add(n.type);
    });
    return Array.from(typesSet);
  }, [notifications]);

  /* ---------- Shared Detail Content ---------- */
  const DetailContent = ({
    notification,
  }: {
    notification: NotificationModel;
  }) => {
    const hasSubject =
      notification.meta?.subjectId && notification.meta?.subjectName;
    const isClassSchedule = notification.type === "class_schedule";

    return (
      <div className="flex flex-col h-full">
        <div className="flex justify-between items-start mb-6 pb-6 border-b border-[var(--color-card-border)]">
          <div className="pr-4">
            <span className="badge-gray mb-3">
              {notification.type
                ? notification.type.replace(/_/g, " ")
                : "broadcast"}
            </span>
            <h2 className="text-2xl font-semibold text-primary tracking-tight leading-tight">
              {notification.title}
            </h2>
          </div>
        </div>

        <div className="space-y-6 flex-1">
          <div>
            <p className="stat-label mb-2">
              Message
            </p>
            <p className="text-secondary leading-relaxed text-sm bg-surface p-5 rounded-3xl">
              {notification.description ||
                "No description provided for this notification."}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 grid place-items-center bg-surface rounded-full text-muted">
                <Clock size={18} />
              </div>
              <div>
                <p className="stat-label">
                  Received
                </p>
                <p className="text-sm font-medium text-primary">
                  {new Date(notification.createdAt).toLocaleString("en-NG", {
                    dateStyle: "medium",
                    timeStyle: "short",
                  })}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 grid place-items-center bg-surface rounded-full text-muted">
                <Info size={18} />
              </div>
              <div>
                <p className="stat-label">
                  Status
                </p>
                <p className="text-sm font-medium text-primary">
                  {notification.isRead ? <span className="badge-gray">Read</span> : <span className="badge-blue">Unread</span>}
                </p>
              </div>
            </div>
          </div>

          {/* Action buttons for Subject / Class */}
          {(hasSubject || isClassSchedule) && (
            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              {hasSubject && (
                <button
                  onClick={() =>
                    goToSubject(
                      notification.meta!.subjectId,
                      notification.meta!.subjectName
                    )
                  }
                  className="btn-primary flex-1"
                >
                  <BookOpen size={16} />
                  View Subject: {notification.meta!.subjectName}
                </button>
              )}

              {isClassSchedule && notification.meta?.subjectId && (
                <button
                  onClick={() => goToClass(notification.meta?.subjectId)}
                  className="btn-accent flex-1"
                >
                  <Calendar size={16} />
                  View Class
                </button>
              )}
            </div>
          )}
        </div>

        <div className="pt-6 divider flex justify-end mt-auto">
          <span className="text-xs text-muted flex items-center gap-1.5">
            <Check size={14} className="text-[var(--color-success)]" /> Delivered
          </span>
        </div>
      </div>
    );
  };

  return (
    <>
      {loading && notifications.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 flex flex-col items-center justify-center bg-surface/90 backdrop-blur-md z-[100]"
        >
          <Loader2 className="w-10 h-10 animate-spin text-primary mb-3" />
          <p className="text-sm text-muted">
            Loading notifications…
          </p>
        </motion.div>
      )}

      <div className="page">
        <div className="space-y-6">
          {/* Header Section */}
          <div className="page-header">
            <div>
              <h1 className="page-title">Notifications</h1>
              <p className="page-subtitle">
                Updates, alerts and messages from your classes and teachers.
              </p>
            </div>
            {getCookie("userType") === "parent" && (
              <button className="btn btn-secondary" onClick={() => navigate("/app/notifications/preferences")}>
                Alert settings and children's classes
              </button>
            )}
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="btn-primary group"
              >
                <CheckCheck className="w-4 h-4 group-hover:scale-110 transition-transform" />{" "}
                Mark all read ({unreadCount})
              </button>
            )}
          </div>

          {/* Filters & Search Toolbar */}
          <div className="card flex flex-col lg:flex-row gap-3 p-3">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-subtle pointer-events-none" />
              <input
                type="text"
                placeholder="Search notifications"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="search-input"
              />
            </div>
            <div className="relative flex-1 lg:max-w-xs">
              <Select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="form-select rounded-full px-5"
              >
                <option value="">All types</option>
                {availableTypes.map((t) => (
                  <option key={t} value={t}>
                    {t.replace(/_/g, " ")}
                  </option>
                ))}
              </Select>
            </div>
            {(search || selectedType) && (
              <button
                onClick={resetFilters}
                className="btn-ghost text-[var(--color-danger)]"
              >
                Reset
              </button>
            )}
          </div>

          {/* Master-Detail Split Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Notification List */}
            <div className="lg:col-span-5 card p-3 max-h-[700px] overflow-y-auto space-y-2">
              <AnimatePresence>
                {filteredNotifications.map((notification: any) => {
                  const isSelected =
                    selectedNotification?._id === notification._id;
                  return (
                    <motion.div
                      key={notification._id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      onClick={() => handleSelectNotification(notification)}
                      className={`p-4 rounded-2xl cursor-pointer transition-colors relative overflow-hidden group ${
 isSelected
 ?"bg-brand text-brand-fg"
                          : notification.isRead
                          ? "hover:bg-surface"
                          : "bg-surface hover:bg-[var(--color-surface-alt)]"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span
                          className={`text-[11px] font-medium capitalize ${
 isSelected ?"opacity-70" : "text-muted"
                          }`}
                        >
                          {notification.type
                            ? notification.type.replace(/_/g, " ")
                            : "broadcast"}
                        </span>
                        {!notification.isRead && (
                          <span className="w-2 h-2 rounded-full bg-[var(--color-info)]" />
                        )}
                      </div>
                      <h4
                        className={`text-base font-semibold leading-snug mb-2 line-clamp-1 ${
 isSelected ?"" : "text-primary"
                        }`}
                      >
                        {notification.title}
                      </h4>
                      <p
                        className={`text-xs line-clamp-2 mb-3 ${
 isSelected
 ?"opacity-70"
                            : "text-muted"
                        }`}
                      >
                        {notification.description ||
                          "No preview description..."}
                      </p>
                      <div className="flex justify-between items-center text-[11px]">
                        <span
                          className={
                            isSelected ? "opacity-60" : "text-muted"
                          }
                        >
                          {new Date(notification.createdAt).toLocaleDateString(
                            "en-NG",
                            {
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            }
                          )}
                        </span>
                        <ChevronRight
                          size={14}
                          className={
                            isSelected ? "opacity-70" : "text-muted"
                          }
                        />
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {!filteredNotifications.length && !loading && (
                <div className="py-20 text-center px-4">
                  <Bell className="w-12 h-12 text-muted mx-auto mb-4 opacity-40" />
                  <p className="text-sm font-semibold text-primary mb-1">
                    No notifications
                  </p>
                  <p className="text-xs text-muted">
                    {getEmptyMessage()}
                  </p>
                </div>
              )}
            </div>

            {/* Right Column: Detailed View Pane (Desktop only) */}
            <div className="hidden lg:flex lg:col-span-7 card p-8 sticky top-6 min-h-[550px] flex-col justify-between">
              {selectedNotification ? (
                <DetailContent notification={selectedNotification} />
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center py-24">
                  <div className="w-16 h-16 bg-surface rounded-full flex items-center justify-center text-muted mb-4">
                    <Bell size={28} />
                  </div>
                  <h3 className="text-xl font-semibold text-primary mb-2">
                    Select a notification
                  </h3>
                  <p className="text-sm text-muted max-w-xs">
                    Choose any message from the list on the left to read its
                    complete contents and metadata.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Detail Overlay */}
      <AnimatePresence>
        {isMobileDetailOpen && selectedNotification && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[90] lg:hidden"
          >
            <div
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
              onClick={handleCloseMobileDetail}
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 320 }}
              className="absolute bottom-0 left-0 right-0 max-h-[92vh] bg-card rounded-t-[1.75rem] shadow-elevated overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between px-5 pt-4 pb-2">
                <div className="w-12 h-1.5 bg-surface rounded-full mx-auto absolute left-1/2 -translate-x-1/2 top-3" />
                <button
                  onClick={handleCloseMobileDetail}
                  className="btn-icon ml-auto"
                  aria-label="Close"
                >
                  <X size={16} />
                </button>
              </div>
              <div className="overflow-y-auto px-5 pb-8 pt-2 flex-1">
                <DetailContent notification={selectedNotification} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
