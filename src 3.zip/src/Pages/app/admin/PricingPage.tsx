import Select from "../../../components/ui/Select";
import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { Plus, Trash2, Power } from "lucide-react";
import { useAppDispatch, useAppSelector } from "../../../store";
import { fetchPricing, savePricing, updatePricing, deletePricing } from "../../../store/features/pricing/pricing.slice";
import { fetchCatalogue } from "../../../store/features/wards/wards.slice";
import type { PriceKind } from "../../../store/models";
import { PageHeader, Panel, EmptyState } from "../../../components/ui";
import { money } from "../../../lib/format";
import { useConfirm } from "../../../contexts/ConfirmContext";

const KINDS: PriceKind[] = ["grade", "subject", "perk"];

export default function PricingPage() {
  const dispatch = useAppDispatch();
  const items = useAppSelector((s) => s.pricing.items);
  const catalogue = useAppSelector((s) => s.wards.catalogue);
  const [f, setF] = useState({ kind: "grade" as PriceKind, refId: "", name: "", ngn: "", usd: "", durationDays: "30" });
  const { confirm } = useConfirm();

  useEffect(() => {
    dispatch(fetchPricing());
    dispatch(fetchCatalogue());
  }, [dispatch]);

  const refs = f.kind === "grade" ? catalogue?.grades.map((g) => ({ id: g._id, name: g.title })) : f.kind === "subject" ? catalogue?.subjects.map((s) => ({ id: s._id, name: s.name })) : [];

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await dispatch(savePricing({ kind: f.kind, refId: f.refId || undefined, name: f.name || refs?.find((x) => x.id === f.refId)?.name || "", prices: { NGN: Number(f.ngn), USD: Number(f.usd) }, durationDays: Number(f.durationDays) } as any));
    if (savePricing.fulfilled.match(r)) { toast.success("Price saved"); setF({ ...f, name: "", ngn: "", usd: "" }); } else toast.error(String(r.payload));
  };

  return (
    <div className="page">
      <PageHeader eyebrow="Admin" title="Pricing" highlight="Pricing" subtitle="Prices in naira and dollars. Checkout is always priced from this list, never from the browser." />
      <Panel title="Add or update a price" subtitle="Saving a price for the same class or subject replaces the old one.">
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-6 items-end">
          <label><span className="form-label">Type</span>
            <Select className="form-input" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value as PriceKind, refId: "" })}>{KINDS.map((k) => <option key={k} value={k}>{k}</option>)}</Select></label>
          <label className="md:col-span-2"><span className="form-label">{f.kind === "perk" ? "Perk name" : "For"}</span>
            {f.kind === "perk" ? <input className="form-input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required />
              : <Select required className="form-input" value={f.refId} onChange={(e) => setF({ ...f, refId: e.target.value })}><option value="">Choose…</option>{refs?.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</Select>}</label>
          <label><span className="form-label">₦ NGN</span><input required type="number" min={0} className="form-input" value={f.ngn} onChange={(e) => setF({ ...f, ngn: e.target.value })} /></label>
          <label><span className="form-label">$ USD</span><input required type="number" min={0} className="form-input" value={f.usd} onChange={(e) => setF({ ...f, usd: e.target.value })} /></label>
          <label><span className="form-label">Days</span><input required type="number" min={1} className="form-input" value={f.durationDays} onChange={(e) => setF({ ...f, durationDays: e.target.value })} /></label>
          <button className="btn btn-primary md:col-span-6 md:w-fit"><Plus size={16} /> Save price</button>
        </form>
      </Panel>
      <Panel title="Price list">
        {items.length === 0 ? <EmptyState title="No prices yet" text="Add the first one above." /> : (
          <table className="w-full text-sm"><thead><tr className="text-left"><th>Item</th><th>Type</th><th>₦</th><th>$</th><th>Days</th><th /></tr></thead>
            <tbody>{items.map((p) => (
              <tr key={p._id} className={p.isActive ? "" : "opacity-50"}>
                <td className="font-medium">{p.name}</td><td>{p.kind}</td><td>{money(p.prices.NGN, "NGN")}</td><td>{money(p.prices.USD, "USD")}</td><td>{p.durationDays}</td>
                <td className="text-right whitespace-nowrap">
                  <button aria-label={p.isActive ? "Turn off" : "Turn on"} className="p-2" onClick={() => dispatch(updatePricing({ id: p._id, changes: { isActive: !p.isActive } }))}><Power size={15} /></button>
                  <button
                    aria-label="Delete"
                    className="p-2 hover:text-red-600"
                    onClick={async () => {
                      if (await confirm({ title: "Delete pricing tier", message: `Delete ${p.name}?`, cancelLabel: "Cancel", confirmLabel: "Delete", danger: true })) {
                        dispatch(deletePricing(p._id));
                      }
                    }}
                  ><Trash2 size={15} /></button>
                </td>
              </tr>))}</tbody></table>)}
      </Panel>
    </div>
  );
}
