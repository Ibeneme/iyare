import { useState } from "react";
import { Eye, EyeOff, KeyRound } from "lucide-react";
import toast from "react-hot-toast";
import { useAppDispatch } from "../../../store";
import { changePassword } from "../../../store/features/account/account.slice";
import { Panel } from "../../../components/ui";

/** "Change password" block for the profile page (all roles). */
export default function ChangePasswordPanel() {
  const dispatch = useAppDispatch();
  const [f, setF] = useState({ current: "", next: "", again: "" });
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const mismatch = f.again !== "" && f.next !== f.again;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (f.next.length < 8) return toast.error("Use at least 8 characters");
    if (mismatch) return toast.error("The new passwords do not match");
    setBusy(true);
    const r = await dispatch(changePassword({ currentPassword: f.current, newPassword: f.next }));
    setBusy(false);
    if (changePassword.fulfilled.match(r)) { toast.success("Password changed"); setF({ current: "", next: "", again: "" }); } else toast.error(String(r.payload));
  };

  const field = (k: "current" | "next" | "again", label: string, auto: string) => (
    <label><span className="form-label">{label}</span>
      <input required type={show ? "text" : "password"} autoComplete={auto} className="form-input" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></label>
  );

  return (
    <Panel title="Change password" subtitle="Choose something you do not use anywhere else.">
      <form onSubmit={submit} className="grid gap-4 md:grid-cols-3 items-end">
        {field("current", "Current password", "current-password")}
        {field("next", "New password", "new-password")}
        {field("again", "Repeat new password", "new-password")}
        <div className="md:col-span-3 flex flex-wrap items-center justify-between gap-3">
          <label className="inline-flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" checked={show} onChange={(e) => setShow(e.target.checked)} />{show ? <EyeOff size={15} /> : <Eye size={15} />} Show passwords</label>
          <div className="flex items-center gap-3">{mismatch && <span className="text-sm text-red-600">Passwords do not match</span>}<button className="btn btn-primary" disabled={busy}><KeyRound size={16} /> {busy ? "Saving…" : "Update password"}</button></div>
        </div>
      </form>
    </Panel>
  );
}
