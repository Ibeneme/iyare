import Select from "../../../components/ui/Select";
import { getCookie, setCookie, clearAuthCookies } from "../../../utils/cookies";
/* ─────────────────────────────────────────────────────────────────────────────
   AdminDashboard.tsx – COMPLETE & FULLY FIXED VERSION
   ───────────────────────────────────────────────────────────────────────────── */
import { useEffect, useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { FaChevronRight, FaUserPlus, FaTrashAlt } from "react-icons/fa";
import { useAdminActions } from "../../../hooks/useAdmins";
import { addAdmin } from "../../../store/features/auth/auth.slice";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../../store/index";
import { useToast } from "../../../contexts/ToastContext";
import {
  createUser,
  fetchAllUsersByType,
} from "../../../store/features/users/users.slice";
import axios from "axios";
import { BASE_URL } from "../../../lib/baseUrl";
import suspendImage from "../../../assets/images/admin/suspend.png";
import removeImage from "../../../assets/images/admin/removeImage.png";
import { Loader2, User, X } from "lucide-react";

const GRADES_API = `${BASE_URL}/api/grades/grades`;

interface AdminUser {
  _id: string;
  isSuspended: boolean;
}

export type UserType =
  | "admin"
  | "teacher"
  | "student"
  | "parent"
  | "notFound"
  | "course"
  | "department"
  | "grade";

export type FilterType = "all" | "active" | "disabled" | "suspended";

interface AdminDashboardProps {
  userType: UserType;
}

interface Grade {
  _id: string;
  title: string;
}

interface Subject {
  _id: string;
  title: string;
  name: string;
}

const filterOptions: Record<UserType, FilterType[]> = {
  admin: ["all", "active", "disabled"],
  parent: ["all", "active", "disabled"],
  student: ["all", "active", "disabled"],
  teacher: ["all", "active", "disabled"],
  notFound: ["all"],
  course: ["all", "active", "disabled"],
  department: ["all", "active", "disabled"],
  grade: ["all", "active", "disabled"],
};

const formatFilterText = (text: string) =>
  text
    .replace(/([A-Z0-9])/g, " $1")
    .trim()
    .replace(/\b\w/g, (l) => l.toUpperCase())
    .replace(/\s+/g, " ");

const AdminDashboard: React.FC<AdminDashboardProps> = ({ userType }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const { addToast } = useToast();
  const { filter: urlFilter } = useParams<{ filter?: string }>();
  const filter = (urlFilter as FilterType) || "all";
  const { suspendAdmin, removeAdmin } = useAdminActions();

  const [isLoading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // User lists
  const [adminsFilter, setAdminsFilter] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [parents, setParents] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);

  // Admin Form
  const [addAdminEmail, setAddAdminEmail] = useState("");
  const [addAdminRole, setAddAdminRole] = useState("");
  const [addAdminFirstName, setAddAdminFirstName] = useState("");
  const [addAdminLastName, setAddAdminLastName] = useState("");
  const [addAdminPassword, setAddAdminPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Common User Form
  const [userFirstName, setUserFirstName] = useState("");
  const [userLastName, setUserLastName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userPhoneNumber, setUserPhoneNumber] = useState("");
  const [parentId, setParentId] = useState("");

  // Teacher-specific
  const [selectedGradeIds, setSelectedGradeIds] = useState<string[]>([]);
  const [selectedSubjectIds, setSelectedSubjectIds] = useState<string[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [subjectsByGrade, setSubjectsByGrade] = useState<
    Record<string, Subject[]>
  >({});
  const [loadingGrades, setLoadingGrades] = useState(false);
  const [loadingSubjects, setLoadingSubjects] = useState(false);

  console.log(loadingSubjects);
  const token = getCookie("token");

  // Errors
  const [formErrors, setFormErrors] = useState({
    email: "",
    role: "",
    firstName: "",
    lastName: "",
    password: "",
  });

  const [formErrorsUsers, setFormErrorsUsers] = useState<{
    firstName?: string;
    lastName?: string;
    email?: string;
    phoneNumber?: string;
    grades?: string;
  }>({});

  const [confirmModal, setConfirmModal] = useState<{
    type: "suspend" | "remove" | "unsuspend";
    id: string | null;
    userType: UserType;
  } | null>(null);

  /* ------------------------------------------------------------------ */
  /* Fetch Users */
  /* ------------------------------------------------------------------ */
  const fetchUsers = async () => {
    setLoading(true);
    const types: UserType[] = ["admin", "teacher", "parent", "student"];
    const promises = types.map((type) =>
      dispatch(fetchAllUsersByType(type as any))
    );

    try {
      const results = await Promise.all(promises);
      results.forEach((res: any) => {
        if (res.payload?.userType && res.payload?.users) {
          switch (res.payload.userType) {
            case "admin":
              setAdminsFilter(res.payload.users);
              break;
            case "teacher":
              setTeachers(res.payload.users);
              break;
            case "parent":
              setParents(res.payload.users);
              break;
            case "student":
              setStudents(res.payload.users);
              break;
          }
        }
      });
    } catch {
      addToast("error", "Failed to fetch data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [userType, filter]);

  /* ------------------------------------------------------------------ */
  /* Fetch Grades */
  /* ------------------------------------------------------------------ */
  useEffect(() => {
    if (!token || userType !== "teacher") return;

    const fetchGrades = async () => {
      try {
        setLoadingGrades(true);
        const res = await axios.get(GRADES_API, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setGrades(res.data.data || res.data || []);
      } catch (err: any) {
        addToast(
          "error",
          err.response?.data?.message || "Failed to load grades"
        );
      } finally {
        setLoadingGrades(false);
      }
    };

    fetchGrades();
  }, [token, userType]);

  /* ------------------------------------------------------------------ */
  /* Fetch Subjects for Selected Grade */
  /* ------------------------------------------------------------------ */
  const fetchSubjectsForGrade = async (gradeId: string) => {
    if (subjectsByGrade[gradeId] || !token) return;

    try {
      setLoadingSubjects(true);
      const res = await axios.get(`${GRADES_API}/subjects/${gradeId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const subjects = res.data.data || [];
      setSubjectsByGrade((prev) => ({ ...prev, [gradeId]: subjects }));
    } catch (err) {
      console.error("Failed to fetch subjects:", err);
    } finally {
      setLoadingSubjects(false);
    }
  };

  useEffect(() => {
    selectedGradeIds.forEach(fetchSubjectsForGrade);
  }, [selectedGradeIds]);

  /* ------------------------------------------------------------------ */
  /* Data Filtering */
  /* ------------------------------------------------------------------ */
  const getSampleData = () => {
    switch (userType) {
      case "admin":
        return adminsFilter;
      case "parent":
        return parents;
      case "student":
        return students;
      case "teacher":
        return teachers;
      default:
        return [];
    }
  };

  const filterData = useMemo(() => {
    const data = getSampleData();
    if (filter === "all") return data;
    return data.filter((item: any) => {
      switch (filter) {
        case "active":
          return !item.isSuspended;
        case "suspended":
        case "disabled":
          return item.isSuspended;
        default:
          return true;
      }
    });
  }, [filter, adminsFilter, parents, students, teachers, userType]);

  /* ------------------------------------------------------------------ */
  /* Actions */
  /* ------------------------------------------------------------------ */
  const handleRemoveAdminClick = (user: AdminUser) => {
    setConfirmModal({ type: "remove", id: user._id, userType });
  };

  const handleConfirmAction = async () => {
    if (!confirmModal?.id) return;
    const { id, type, userType } = confirmModal;

    setLoading(true);
    setConfirmModal(null);

    const action =
      type === "remove"
        ? removeAdmin(id, userType as any)
        : suspendAdmin(id, userType as any);

    try {
      const res = await action;
      if (res.success) {
        addToast("success", "Action successful");
        fetchUsers();
      } else {
        addToast("error", "Action failed");
      }
    } catch {
      addToast("error", "Something went wrong!");
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (id: string) => {
    navigate(`/app/user/${userType}/${id}`);
  };

  const getTitle = () =>
    userType
      ? `${userType.charAt(0).toUpperCase() + userType.slice(1)} Dashboard`
      : "Dashboard";

  /* ------------------------------------------------------------------ */
  /* Reset Forms */
  /* ------------------------------------------------------------------ */
  const resetAdminForm = () => {
    setAddAdminEmail("");
    setAddAdminRole("");
    setAddAdminFirstName("");
    setAddAdminLastName("");
    setAddAdminPassword("");
    setFormErrors({
      email: "",
      role: "",
      firstName: "",
      lastName: "",
      password: "",
    });
  };

  const resetUserForm = () => {
    setUserFirstName("");
    setUserLastName("");
    setUserEmail("");
    setUserPhoneNumber("");
    setParentId("");
    setSelectedGradeIds([]);
    setSelectedSubjectIds([]);
    setFormErrorsUsers({});
  };

  /* ------------------------------------------------------------------ */
  /* Submit Form */
  /* ------------------------------------------------------------------ */
  const handleSubmitAll = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      setLoading(true);

      if (userType === "admin") {
        const errors: any = {};
        if (!addAdminEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(addAdminEmail))
          errors.email = "Valid email is required";
        if (!addAdminRole) errors.role = "Role is required";
        if (!addAdminFirstName) errors.firstName = "First name is required";
        if (!addAdminLastName) errors.lastName = "Last name is required";
        if (!addAdminPassword || addAdminPassword.length < 6)
          errors.password = "Password must be at least 6 characters";

        setFormErrors(errors);
        if (Object.keys(errors).length > 0) {
          setLoading(false);
          return;
        }

        const res = await dispatch(
          addAdmin({
            email: addAdminEmail,
            role: addAdminRole,
            firstName: addAdminFirstName,
            lastName: addAdminLastName,
            password: addAdminPassword,
          })
        ).unwrap();

        if (res.success) {
          addToast("success", "Admin added successfully!");
          resetAdminForm();
          fetchUsers();
          setIsModalOpen(false);
        } else {
          addToast("error", res.message || "Failed to add admin");
        }
      } else if (["parent", "student", "teacher"].includes(userType)) {
        const errors: any = {};
        if (!userFirstName) errors.firstName = "First name is required";
        if (!userLastName) errors.lastName = "Last name is required";
        if (!userEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(userEmail))
          errors.email = "Valid email is required";
        if (!userPhoneNumber) errors.phoneNumber = "Phone number is required";
        if (userType === "teacher" && selectedGradeIds.length === 0)
          errors.grades = "Please select at least one grade";

        setFormErrorsUsers(errors);
        if (Object.keys(errors).length > 0) {
          setLoading(false);
          return;
        }

        const body: any = {
          firstName: userFirstName,
          lastName: userLastName,
          email: userEmail,
          phoneNumber: userPhoneNumber,
          userType,
          ...(userType === "student" && parentId && { parentId }),
          ...(userType === "teacher" && {
            gradeIds: selectedGradeIds,
            subjectIds: selectedSubjectIds,
          }),
        };

        const res: any = await dispatch(createUser(body)).unwrap();

        if (res.success) {
          addToast(
            "success",
            `${
              userType.charAt(0).toUpperCase() + userType.slice(1)
            } created successfully!`
          );
          resetUserForm();
          fetchUsers();
          setIsModalOpen(false);
        } else {
          addToast("error", res.message || "Failed to create user");
        }
      }
    } catch (err: any) {
      addToast("error", err.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  /* ------------------------------------------------------------------ */
  /* Close Modal & Reset */
  /* ------------------------------------------------------------------ */
  const closeModal = () => {
    setIsModalOpen(false);
    resetAdminForm();
    resetUserForm();
  };

  const allData = getSampleData();
  const totalCount = allData.length;
  const activeCount = allData.filter((u: any) => !u.isSuspended).length;
  const suspendedCount = totalCount - activeCount;
  const canAdd = userType === "teacher" || userType === "admin" || userType === "student";

  const fullName = (user: any) =>
    user.name || `${user.firstName || ""} ${user.lastName || ""}`.trim() || "—";

  return (
    <div className="page">
      {isLoading && !isModalOpen ? (
        <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-[var(--color-muted)]" />
          <p className="text-sm text-[var(--color-muted)]">Loading…</p>
        </div>
      ) : (
        <>
          {/* Header */}
          <header className="page-header">
            <div>
              <h1 className="page-title capitalize">{userType}s</h1>
              <p className="page-subtitle">Everyone registered as a {userType} on the platform.</p>
            </div>
            {canAdd && (
              <button onClick={() => navigate(`/app/people/${userType}/new`)} className="btn-primary">
                <FaUserPlus /> Add {userType}
              </button>
            )}
          </header>

          {/* Stat strip */}
          <section aria-label="Summary" className="card grid grid-cols-3 divide-x divide-[var(--color-card-border)]">
            {[
              { label: "Total", value: totalCount },
              { label: "Active", value: activeCount },
              { label: "Suspended", value: suspendedCount },
            ].map((s) => (
              <div key={s.label} className="px-4 sm:px-6 py-4">
                <p className="stat-label">{s.label}</p>
                <p className="stat-value">{s.value}</p>
              </div>
            ))}
          </section>

          {/* Filters */}
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter by status">
            {filterOptions[userType]?.map((f) => (
              <button
                key={f}
                role="tab"
                aria-selected={filter === f}
                onClick={() => navigate(`/app/users/${userType}/${f}`)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  filter === f
                    ? "bg-[var(--color-brand)] text-[var(--color-brand-fg)]"
                    : "bg-[var(--color-card)] text-[var(--color-muted)] hover:text-[var(--color-primary)]"
                }`}
              >
                {formatFilterText(f)}
              </button>
            ))}
          </div>

          {/* Table (desktop) */}
          <div className="card overflow-hidden">
            {filterData.length === 0 ? (
              <div className="py-20 flex flex-col items-center gap-3 text-[var(--color-muted)]">
                <User size={40} className="opacity-40" />
                <p className="text-sm font-medium">No {userType}s found</p>
              </div>
            ) : (
              <>
                <div className="hidden md:block overflow-x-auto px-2 pb-2">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th className="text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filterData.map((user: any) => (
                        <tr key={user._id} className="cursor-pointer" onClick={() => handleViewDetails(user._id)}>
                          <td className="whitespace-nowrap">
                            <div className="flex items-center gap-3">
                              <span className="w-9 h-9 rounded-full bg-[var(--color-surface-alt)] grid place-items-center text-sm font-semibold text-[var(--color-primary)]">
                                {user.firstName?.[0] || user.name?.[0] || "?"}
                              </span>
                              <span className="font-medium">{fullName(user)}</span>
                            </div>
                          </td>
                          <td className="whitespace-nowrap text-[var(--color-muted)]">{user.email || "—"}</td>
                          <td>
                            <span className={user.isSuspended ? "badge-red" : "badge-green"}>
                              {user.isSuspended ? "Suspended" : "Active"}
                            </span>
                          </td>
                          <td className="whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1">
                              {canAdd && (
                                <button
                                  aria-label={`Remove ${fullName(user)}`}
                                  onClick={(e) => { e.stopPropagation(); handleRemoveAdminClick(user); }}
                                  className="w-9 h-9 grid place-items-center rounded-full text-[var(--color-muted)] hover:text-[var(--color-danger)] hover:bg-[var(--color-danger-bg)] transition-colors"
                                >
                                  <FaTrashAlt className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <span className="w-9 h-9 grid place-items-center text-[var(--color-subtle)]">
                                <FaChevronRight className="w-3.5 h-3.5" />
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Cards (mobile) */}
                <ul className="md:hidden divide-y divide-[var(--color-card-border)]">
                  {filterData.map((user: any) => (
                    <li key={user._id} className="p-4 flex items-center gap-3 cursor-pointer" onClick={() => handleViewDetails(user._id)}>
                      <span className="w-10 h-10 rounded-full bg-[var(--color-surface-alt)] grid place-items-center font-semibold shrink-0">
                        {user.firstName?.[0] || user.name?.[0] || "?"}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium truncate">{fullName(user)}</p>
                        <p className="text-xs text-[var(--color-muted)] truncate">{user.email || "—"}</p>
                      </div>
                      <span className={user.isSuspended ? "badge-red" : "badge-green"}>
                        {user.isSuspended ? "Suspended" : "Active"}
                      </span>
                      {canAdd && (
                        <button
                          aria-label={`Remove ${fullName(user)}`}
                          onClick={(e) => { e.stopPropagation(); handleRemoveAdminClick(user); }}
                          className="w-9 h-9 grid place-items-center rounded-full text-[var(--color-muted)] hover:text-[var(--color-danger)] hover:bg-[var(--color-danger-bg)]"
                        >
                          <FaTrashAlt className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>

          {/* ═══════════════════════════════════════════════════════════════
                  ADD USER MODAL – Restyled
                ═══════════════════════════════════════════════════════════════ */}
          {isModalOpen && (
            <>
              <div
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
                onClick={closeModal}
              />
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="bg-[var(--color-card)] rounded-3xl shadow-[var(--shadow-elevated)] w-full max-w-2xl mx-auto my-8 overflow-hidden border border-[var(--color-card-border)]"
                >
                  {/* Header */}
                  <div className="relative bg-[var(--color-card)] border-b border-[var(--color-card-border)] px-8 py-7">
                    <button
                      onClick={closeModal}
                      className="absolute top-5 right-5 w-10 h-10 rounded-full bg-[var(--color-surface)] hover:bg-[var(--color-surface-alt)] flex items-center justify-center transition-colors"
                    >
                      <X className="w-5 h-5 text-[var(--color-primary)]" />
                    </button>

                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-yellow-400 flex items-center justify-center text-[var(--color-primary)] shadow-[var(--shadow-elevated)]">
                        <FaUserPlus className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="text-2xl font-semibold text-[var(--color-primary)] tracking-tight">
                          Add New{" "}
                          {userType.charAt(0).toUpperCase() + userType.slice(1)}
                        </h2>
                        <p className="text-[var(--color-muted)] text-sm mt-0.5">
                          Fill in the details to create a new account
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Body */}
                  <form
                    onSubmit={handleSubmitAll}
                    className="p-8 space-y-6 max-h-[70vh] overflow-y-auto"
                  >
                    {/* ─── Admin Form ─── */}
                    {userType === "admin" && (
                      <div className="space-y-6">
                        <div>
                          <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                            Email Address
                          </label>
                          <input
                            type="email"
                            value={addAdminEmail}
                            onChange={(e) => setAddAdminEmail(e.target.value)}
                            placeholder="admin@school.edu"
                            className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                          />
                          {formErrors.email && (
                            <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                              {formErrors.email}
                            </p>
                          )}
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-3">
                            Role
                          </label>
                          <div className="flex gap-4">
                            {["superadmin", "admin"].map((role) => (
                              <label
                                key={role}
                                className={`flex-1 flex items-center gap-3 p-4 rounded-2xl border cursor-pointer transition-all ${
                                  addAdminRole === role
                                    ? "border-yellow-400 bg-[var(--color-warning-bg)]"
                                    : "border-[var(--color-card-border)] bg-[var(--color-card)] hover:border-[var(--color-card-border)]"
                                }`}
                              >
                                <input
                                  type="radio"
                                  name="adminRole"
                                  value={role}
                                  checked={addAdminRole === role}
                                  onChange={(e) =>
                                    setAddAdminRole(e.target.value)
                                  }
                                  className="sr-only"
                                />
                                <div
                                  className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                                    addAdminRole === role
                                      ? "border-[var(--color-primary)] bg-[var(--color-brand)]"
                                      : "border-[var(--color-card-border)]"
                                  }`}
                                >
                                  {addAdminRole === role && (
                                    <div className="w-2 h-2 bg-yellow-400 rounded-full" />
                                  )}
                                </div>
                                <span
                                  className={`font-semibold text-sm ${
                                    addAdminRole === role
                                      ? "text-[var(--color-primary)]"
                                      : "text-[var(--color-primary)]"
                                  }`}
                                >
                                  {role === "superadmin"
                                    ? "Super Admin"
                                    : "Admin"}
                                </span>
                              </label>
                            ))}
                          </div>
                          {formErrors.role && (
                            <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                              {formErrors.role}
                            </p>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                          <div>
                            <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                              First Name
                            </label>
                            <input
                              type="text"
                              value={addAdminFirstName}
                              onChange={(e) =>
                                setAddAdminFirstName(e.target.value)
                              }
                              placeholder="John"
                              className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                            />
                            {formErrors.firstName && (
                              <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                                {formErrors.firstName}
                              </p>
                            )}
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                              Last Name
                            </label>
                            <input
                              type="text"
                              value={addAdminLastName}
                              onChange={(e) =>
                                setAddAdminLastName(e.target.value)
                              }
                              placeholder="Doe"
                              className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                            />
                            {formErrors.lastName && (
                              <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                                {formErrors.lastName}
                              </p>
                            )}
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                            Password
                          </label>
                          <div className="relative">
                            <input
                              type={showPassword ? "text" : "password"}
                              value={addAdminPassword}
                              onChange={(e) =>
                                setAddAdminPassword(e.target.value)
                              }
                              placeholder="••••••••"
                              className="w-full px-5 py-3.5 pr-16 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--color-primary)] font-semibold text-xs  tracking-tight hover:text-[var(--color-primary)]"
                            >
                              {showPassword ? "Hide" : "Show"}
                            </button>
                          </div>
                          {formErrors.password && (
                            <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                              {formErrors.password}
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* ─── Parent / Student / Teacher Form ─── */}
                    {["parent", "student", "teacher"].includes(userType) && (
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                          <div>
                            <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                              First Name
                            </label>
                            <input
                              type="text"
                              value={userFirstName}
                              onChange={(e) => setUserFirstName(e.target.value)}
                              placeholder="Emma"
                              className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                            />
                            {formErrorsUsers.firstName && (
                              <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                                {formErrorsUsers.firstName}
                              </p>
                            )}
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                              Last Name
                            </label>
                            <input
                              type="text"
                              value={userLastName}
                              onChange={(e) => setUserLastName(e.target.value)}
                              placeholder="Wilson"
                              className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                            />
                            {formErrorsUsers.lastName && (
                              <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                                {formErrorsUsers.lastName}
                              </p>
                            )}
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                            Email Address
                          </label>
                          <input
                            type="email"
                            value={userEmail}
                            onChange={(e) => setUserEmail(e.target.value)}
                            placeholder="emma.wilson@school.com"
                            className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                          />
                          {formErrorsUsers.email && (
                            <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                              {formErrorsUsers.email}
                            </p>
                          )}
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                            Phone Number
                          </label>
                          <input
                            type="text"
                            value={userPhoneNumber}
                            onChange={(e) => setUserPhoneNumber(e.target.value)}
                            placeholder="+234 801 234 5678"
                            className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                          />
                          {formErrorsUsers.phoneNumber && (
                            <p className="text-[var(--color-danger)] text-xs font-semibold mt-1.5">
                              {formErrorsUsers.phoneNumber}
                            </p>
                          )}
                        </div>

                        {userType === "student" && (
                          <div>
                            <label className="block text-[11px] font-semibold text-[var(--color-muted)]  tracking-tight mb-2">
                              Select Parent
                            </label>
                            <Select
                              value={parentId}
                              onChange={(e) => setParentId(e.target.value)}
                              className="w-full px-5 py-3.5 bg-[var(--color-surface)] border border-[var(--color-card-border)] rounded-2xl text-[var(--color-primary)] font-medium focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition"
                            >
                              <option value="">Choose parent...</option>
                              {parents.map((p: any) => (
                                <option key={p._id} value={p._id}>
                                  {p.firstName} {p.lastName} • {p.email}
                                </option>
                              ))}
                            </Select>
                          </div>
                        )}

                        {userType === "teacher" && (
                          <>
                            {/* Grades */}
                            <div className="pt-2">
                              <div className="flex items-center justify-between mb-4">
                                <div className="flex items-center gap-2">
                                  <span className="w-6 h-6 rounded-lg bg-[var(--color-brand)] text-[var(--color-brand-fg)] flex items-center justify-center text-xs font-semibold">
                                    1
                                  </span>
                                  <h3 className="text-sm font-semibold text-[var(--color-primary)]">
                                    Assign Grades{" "}
                                    <span className="text-[var(--color-danger)]">*</span>
                                  </h3>
                                </div>
                                <span className="text-xs font-semibold text-[var(--color-muted)]">
                                  {selectedGradeIds.length} selected
                                </span>
                              </div>

                              {loadingGrades ? (
                                <div className="flex justify-center py-8">
                                  <Loader2 className="w-8 h-8 animate-spin text-[var(--color-primary)]" />
                                </div>
                              ) : (
                                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                                  {grades.map((grade) => {
                                    const isSelected =
                                      selectedGradeIds.includes(grade._id);
                                    return (
                                      <label
                                        key={grade._id}
                                        className="cursor-pointer"
                                      >
                                        <input
                                          type="checkbox"
                                          checked={isSelected}
                                          onChange={() =>
                                            setSelectedGradeIds((prev) =>
                                              prev.includes(grade._id)
                                                ? prev.filter(
                                                    (id) => id !== grade._id
                                                  )
                                                : [...prev, grade._id]
                                            )
                                          }
                                          className="sr-only"
                                        />
                                        <div
                                          className={`p-3.5 rounded-2xl border text-center transition-all ${
                                            isSelected
                                              ? "bg-[var(--color-brand)] border-[var(--color-primary)] text-[var(--color-brand-fg)] shadow-[var(--shadow-card)] scale-[1.02]"
                                              : "bg-[var(--color-card)] border-[var(--color-card-border)] hover:border-[var(--color-card-border)] text-[var(--color-primary)]"
                                          }`}
                                        >
                                          <p className="font-semibold text-lg leading-none">
                                            {grade.title.match(/\d+/)?.[0] ||
                                              "?"}
                                          </p>
                                          <p
                                            className={`text-[10px] font-semibold mt-1  tracking-tight ${
                                              isSelected
                                                ? "text-white/70"
                                                : "text-[var(--color-muted)]"
                                            }`}
                                          >
                                            {grade.title
                                              .replace(/\d+/g, "")
                                              .trim() || "Grade"}
                                          </p>
                                        </div>
                                      </label>
                                    );
                                  })}
                                </div>
                              )}
                              {formErrorsUsers.grades && (
                                <p className="text-[var(--color-danger)] text-xs font-semibold mt-2">
                                  {formErrorsUsers.grades}
                                </p>
                              )}
                            </div>

                            {/* Subjects */}
                            {selectedGradeIds.length > 0 && (
                              <div className="pt-2 space-y-4">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <span className="w-6 h-6 rounded-lg bg-yellow-400 text-[var(--color-primary)] flex items-center justify-center text-xs font-semibold">
                                      2
                                    </span>
                                    <h3 className="text-sm font-semibold text-[var(--color-primary)]">
                                      Assign Subjects
                                    </h3>
                                  </div>
                                  <span className="text-xs font-semibold text-[var(--color-muted)]">
                                    {selectedSubjectIds.length} selected
                                  </span>
                                </div>

                                {selectedGradeIds.map((gradeId) => {
                                  const grade = grades.find(
                                    (g) => g._id === gradeId
                                  );
                                  const subjects =
                                    subjectsByGrade[gradeId] || [];
                                  if (subjects.length === 0) return null;

                                  return (
                                    <div
                                      key={gradeId}
                                      className="bg-[var(--color-surface)] rounded-2xl p-5 border border-[var(--color-card-border)]"
                                    >
                                      <h4 className="font-semibold text-[var(--color-primary)] text-sm mb-3">
                                        {grade?.title}
                                      </h4>
                                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                                        {subjects.map((subject) => {
                                          const isSelected =
                                            selectedSubjectIds.includes(
                                              subject._id
                                            );
                                          return (
                                            <label
                                              key={subject._id}
                                              className={`flex items-center gap-2.5 p-3 rounded-xl cursor-pointer transition-all ${
                                                isSelected
                                                  ? "bg-[var(--color-brand)] text-[var(--color-brand-fg)]"
                                                  : "bg-[var(--color-card)] border border-[var(--color-card-border)] hover:border-[var(--color-card-border)]"
                                              }`}
                                            >
                                              <input
                                                type="checkbox"
                                                checked={isSelected}
                                                onChange={() =>
                                                  setSelectedSubjectIds(
                                                    (prev) =>
                                                      prev.includes(subject._id)
                                                        ? prev.filter(
                                                            (id) =>
                                                              id !== subject._id
                                                          )
                                                        : [...prev, subject._id]
                                                  )
                                                }
                                                className="sr-only"
                                              />
                                              <div
                                                className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${
                                                  isSelected
                                                    ? "border-yellow-400 bg-yellow-400"
                                                    : "border-[var(--color-card-border)]"
                                                }`}
                                              >
                                                {isSelected && (
                                                  <div className="w-1.5 h-1.5 bg-[var(--color-brand)] rounded-full" />
                                                )}
                                              </div>
                                              <span
                                                className={`text-sm font-semibold truncate ${
                                                  isSelected
                                                    ? "text-yellow-400"
                                                    : "text-[var(--color-primary)]"
                                                }`}
                                              >
                                                {subject.name || subject.title}
                                              </span>
                                            </label>
                                          );
                                        })}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    )}

                    {/* Footer Actions */}
                    <div className="flex gap-3 pt-6 border-t border-[var(--color-card-border)]">
                      <button
                        type="button"
                        onClick={closeModal}
                        className="flex-1 py-4 bg-[var(--color-surface-alt)] text-[var(--color-primary)] rounded-full font-semibold text-sm  tracking-tight hover:bg-[var(--color-surface-alt)] transition"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="flex-1 py-4 bg-[var(--color-brand)] text-[var(--color-brand-fg)] rounded-full font-semibold text-sm  tracking-tight hover:bg-[var(--color-brand-hover)] transition shadow-[var(--shadow-elevated)] disabled:opacity-60"
                      >
                        {isLoading
                          ? "Creating..."
                          : `Create ${
                              userType.charAt(0).toUpperCase() +
                              userType.slice(1)
                            }`}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </>
          )}

          {/* ═══════════════════════════════════════════════════════════════
                  CONFIRM DELETE / SUSPEND MODAL – Restyled
                ═══════════════════════════════════════════════════════════════ */}
          {confirmModal && (
            <>
              <div
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
                onClick={() => setConfirmModal(null)}
              />
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="bg-[var(--color-card)] rounded-3xl shadow-[var(--shadow-elevated)] max-w-md w-full overflow-hidden border border-[var(--color-card-border)]"
                >
                  {/* Colored Header */}
                  <div
                    className={`px-8 py-10 text-center relative ${
                      confirmModal.type === "remove"
                        ? "bg-[var(--color-danger-bg)]"
                        : "bg-[var(--color-warning-bg)]"
                    }`}
                  >
                    <div className="w-24 h-24 mx-auto mb-5 bg-[var(--color-card)] rounded-full flex items-center justify-center backdrop-blur-sm">
                      <img
                        src={
                          confirmModal.type === "remove"
                            ? removeImage
                            : suspendImage
                        }
                        alt=""
                        className="w-14 h-14"
                      />
                    </div>
                    <h3 className="text-2xl font-semibold text-[var(--color-primary)] tracking-tight">
                      {confirmModal.type === "remove" ? "Delete" : "Suspend"}{" "}
                      {userType}?
                    </h3>
                  </div>

                  {/* Body */}
                  <div className="p-8">
                    <p className="text-center text-[var(--color-primary)] font-medium leading-relaxed">
                      You are about to{" "}
                      <span
                        className={`font-semibold ${
                          confirmModal.type === "remove"
                            ? "text-[var(--color-danger)]"
                            : "text-[var(--color-warning)]"
                        }`}
                      >
                        {confirmModal.type === "remove"
                          ? "permanently delete"
                          : "suspend"}
                      </span>{" "}
                      this {userType}.
                    </p>
                    <p className="text-center text-sm text-[var(--color-muted)] mt-2">
                      All associated data will be affected.
                    </p>

                    <div className="flex gap-3 mt-8">
                      <button
                        onClick={() => setConfirmModal(null)}
                        className="flex-1 py-4 bg-[var(--color-surface-alt)] text-[var(--color-primary)] rounded-2xl font-semibold text-sm  tracking-tight hover:bg-[var(--color-surface-alt)] transition"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleConfirmAction}
                        className={`flex-1 py-4 text-[var(--color-brand-fg)] rounded-full font-semibold text-sm  tracking-tight shadow-[var(--shadow-elevated)] transition hover:scale-[1.02] ${
                          confirmModal.type === "remove"
                            ? "bg-[var(--color-brand)] hover:from-red-700 hover:to-rose-800"
                            : "bg-[var(--color-brand)] hover:from-amber-600 hover:to-orange-700"
                        }`}
                      >
                        Yes,{" "}
                        {confirmModal.type === "remove"
                          ? "Delete Forever"
                          : "Suspend User"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default AdminDashboard;
