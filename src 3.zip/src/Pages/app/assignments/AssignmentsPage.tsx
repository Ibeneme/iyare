import { useEffect, useState, useMemo } from "react";
import {
  Loader2,
  Search,
  FileText,
  Notebook,
  Megaphone,
  ChevronRight,

  X,

  BookOpen,

} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useDispatch } from "react-redux";
import { AppDispatch } from "../../../store/index";
import { fetchAllResources } from "../../../store/features/resources/resources.slice";

export default function AssignmentsManager() {
  const dispatch = useDispatch<AppDispatch>();
  const [searchQuery, setSearchQuery] = useState("");
  const [parentData, setParentData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedResource, setSelectedResource] = useState<any>(null);

  useEffect(() => {
    dispatch(fetchAllResources())
      .unwrap()
      .then((res: any) => setParentData(res?.data || []))
      .catch((err) => setError(err?.message || "Sync Failed"))
      .finally(() => setLoading(false));
  }, [dispatch]);

  const formatDate = (date: string) =>
    new Date(date).toLocaleDateString("en-NG", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
    console.log(error)
  const filteredSubjects = useMemo(() => {
    const allSubjects = parentData.flatMap((admin) => admin.data || []);
    if (!searchQuery.trim()) return allSubjects;
    const q = searchQuery.toLowerCase();
    return allSubjects.filter(
      (subj) =>
        subj.name.toLowerCase().includes(q) ||
        subj.code.toLowerCase().includes(q) ||
        Object.values(subj.resources).some((arr: any) =>
          arr.some((r: any) => r.title.toLowerCase().includes(q))
        )
    );
  }, [parentData, searchQuery]);

  // Helper to render a group of resources
  const ResourceSection = ({
    title,
    items,
    icon: Icon,
    colorClass,
    subj,
  }: any) => {
    if (!items || items.length === 0) return null;
    return (
      <div className="space-y-3 pt-4">
        <div className="flex items-center gap-2 mb-2">
          <Icon size={14} className={colorClass} />
          <h3
            className={`text-xs font-semibold tracking-[0.2em] ${colorClass}`}
          >
            {title} ({items.length})
          </h3>
        </div>
        <div className="space-y-2">
          {items.map((item: any) => (
            <button
              key={item._id}
              onClick={() =>
                setSelectedResource({
                  ...item,
                  type: title,
                  subjectName: subj.name,
                  subjectCode: subj.code,
                })
              }
              className="w-full flex items-center justify-between p-4 rounded-2xl bg-[var(--color-card)] shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-elevated)] hover:bg-[var(--color-success-bg)]/30 transition-all text-left group"
            >
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-sm text-[var(--color-primary)] tracking-tight truncate">
                  {item.title}
                </h4>
                <p className="text-xs font-bold text-[var(--color-subtle)] mt-0.5">
                  Posted {formatDate(item.createdAt)}
                </p>
              </div>
              <ChevronRight
                size={16}
                className="text-[var(--color-subtle)] group-hover:text-[var(--color-primary)] group-hover:translate-x-1 transition-all"
              />
            </button>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[var(--color-surface)] px-4 sm:px-6 lg:px-8 py-6 sm:py-8 text-left">
      <div className="max-w-7xl mx-auto">
        {/* Header - Aligned Left */}
        <header className="mb-12 space-y-4 text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--color-success-bg)] text-[var(--color-primary)] rounded-lg text-xs font-semibold border border-emerald-100">
            <BookOpen size={12} /> Academic Repository
          </div>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[var(--color-primary)] tracking-tight">
            Curriculum Updates
          </h1>
          <div className="max-w-md relative">
            <Search
              className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--color-subtle)]"
              size={18}
            />
            <input
              type="text"
              placeholder="Search subjects or materials..."
              className="w-full pl-12 pr-4 py-3 bg-[var(--color-card)] border border-[var(--color-card-border)] rounded-xl outline-none font-bold text-[var(--color-primary)] focus:border-[var(--color-primary)] transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </header>

        {loading ? (
          <div className="flex justify-start py-20">
            <Loader2 className="w-10 h-10 animate-spin text-[var(--color-primary)]" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredSubjects.map((subj) => {
              const hasContent = Object.values(subj.resources).some(
                (arr: any) => arr.length > 0
              );
              if (!hasContent) return null;

              return (
                <div
                  key={subj.subjectId}
                  className="bg-[var(--color-surface)] rounded-[1.5rem] p-6 border border-[var(--color-card-border)] flex flex-col h-full"
                >
                  {/* Subject Header */}
                  <div className="mb-6 border-b border-[var(--color-card-border)] pb-4">
                    <span className="text-xs font-semibold text-[var(--color-warning)] block mb-1">
                      {subj.code}
                    </span>
                    <h2 className="text-xl font-semibold text-[var(--color-primary)] tracking-tight">
                      {subj.name}
                    </h2>
                  </div>

                  {/* Grouped Resource Content */}
                  <div className="space-y-6 divide-y divide-slate-100">
                    <ResourceSection
                      title="Assignments"
                      items={subj.resources.assignments}
                      icon={FileText}
                      colorClass="text-orange-600"
                      subj={subj}
                    />
                    <ResourceSection
                      title="Academic Notes"
                      items={subj.resources.notes}
                      icon={Notebook}
                      colorClass="text-purple-600"
                      subj={subj}
                    />
                    <ResourceSection
                      title="Announcements"
                      items={subj.resources.announcements}
                      icon={Megaphone}
                      colorClass="text-teal-600"
                      subj={subj}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal - Aligned Content Left */}
      <AnimatePresence>
        {selectedResource && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedResource(null)}
              className="absolute inset-0 bg-[var(--color-brand)] text-[var(--color-brand-fg)] backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              className="relative bg-[var(--color-card)] w-full max-w-xl rounded-[1.5rem] overflow-hidden"
            >
              <div className="p-8 md:p-10 text-left">
                <div className="flex justify-between items-start mb-6">
                  <div className="space-y-1">
                    <span className="text-xs font-semibold text-[var(--color-warning)] ">
                      {selectedResource.type} Entry
                    </span>
                    <h2 className="text-3xl font-semibold text-[var(--color-primary)] tracking-tight">
                      {selectedResource.title}
                    </h2>
                  </div>
                  <button
                    onClick={() => setSelectedResource(null)}
                    className="p-2 text-[var(--color-subtle)] hover:text-[var(--color-danger)] transition-all"
                  >
                    <X size={24} />
                  </button>
                </div>

                <div className="flex gap-10 mb-8 text-left">
                  <div>
                    <p className="text-xs font-semibold text-[var(--color-subtle)] ">
                      Subject
                    </p>
                    <p className="text-sm font-semibold text-[var(--color-primary)]">
                      {selectedResource.subjectName}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-[var(--color-subtle)] ">
                      Date
                    </p>
                    <p className="text-sm font-semibold text-[var(--color-primary)]">
                      {formatDate(selectedResource.createdAt)}
                    </p>
                  </div>
                </div>

                <div className="space-y-3 text-left">
                  <p className="text-xs font-semibold text-[var(--color-subtle)] ">
                    Description
                  </p>
                  <div className="text-slate-700 font-bold leading-relaxed bg-[var(--color-surface)] p-6 rounded-2xl border border-[var(--color-card-border)] whitespace-pre-wrap max-h-60 overflow-y-auto">
                    {selectedResource.description}
                  </div>
                </div>

                <button
                  onClick={() => setSelectedResource(null)}
                  className="w-full mt-8 py-5 bg-[var(--color-brand)] text-[var(--color-brand-fg)] rounded-full font-semibold text-xs"
                >
                  Close Document
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
