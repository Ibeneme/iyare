import Select from "../../../components/ui/Select";
import { useEffect, useMemo, useState } from "react";
import { CreditCard, Loader2, Receipt, Wallet, TrendingUp } from "lucide-react";
import toast from "react-hot-toast";
import { useAppDispatch, useAppSelector } from "../../../store";
import { fetchMyTransactions, fetchAllTransactions } from "../../../store/features/payments/transactions.slice";
import { startCheckout } from "../../../store/features/payments/checkout.slice";
import { fetchWardAccess } from "../../../store/features/access/access.slice";
import { fetchWards } from "../../../store/features/wards/wards.slice";
import type { Currency, TransactionStatus } from "../../../store/models";
import useAuth from "../../../hooks/useAuth";
import { PageHeader, Panel, StatCard, EmptyState, StatusPill } from "../../../components/ui";
import { day, money, personName } from "../../../lib/format";

export default function PaymentsPage() {
  const dispatch = useAppDispatch();
  const { isParent, isAdmin, email } = useAuth();
  const { items, total, revenue, status } = useAppSelector((s) => s.transactions);
  const wards = useAppSelector((s) => s.wards.items);
  const wardAccess = useAppSelector((s) => s.access.wards);
  const checkout = useAppSelector((s) => s.checkout);
  const [currency, setCurrency] = useState<Currency>("NGN");
  const [picked, setPicked] = useState<string[]>([]);
  const [filter, setFilter] = useState<"" | TransactionStatus>("");

  useEffect(() => {
    if (isAdmin) dispatch(fetchAllTransactions({ status: filter || undefined }));
    else {
      dispatch(fetchMyTransactions({ status: filter || undefined }));
      dispatch(fetchWards());
      dispatch(fetchWardAccess());
    }
  }, [dispatch, isAdmin, filter]);

  const dueIds = useMemo(() => wardAccess.filter((w) => w.needsRenewal).map((w) => w.studentId), [wardAccess]);
  useEffect(() => setPicked(dueIds), [dueIds.join(",")]); // eslint-disable-line

  const pay = async () => {
    if (!picked.length) return toast.error("Choose at least one child");
    const r = await dispatch(startCheckout({ email: email || "", currency, studentDetails: picked.map((_id) => ({ _id })) }));
    if (startCheckout.fulfilled.match(r)) window.location.href = r.payload.checkout_url; // Paystack hosted page
    else toast.error(String(r.payload));
  };

  const successTotal = revenue?.[currency]?.total ?? 0;

  return (
    <div className="page">
      <PageHeader eyebrow={isAdmin ? "Admin" : "Billing"} title={isAdmin ? "All payments" : "Payments"} highlight={isAdmin ? "payments" : "Payments"}
        subtitle={isAdmin ? "Every Paystack transaction on the platform." : "Pay for your children's lessons and see your receipts."} />

      {isAdmin && (
        <div className="grid-stats">
          <StatCard label="Transactions" value={total} icon={Receipt} tone="plain" />
          <StatCard label="Revenue (₦)" value={money(revenue?.NGN?.total ?? 0, "NGN")} icon={TrendingUp} tone="green" />
          <StatCard label="Revenue ($)" value={money(revenue?.USD?.total ?? 0, "USD")} icon={Wallet} tone="yellow" />
        </div>
      )}

      {isParent && (
        <Panel variant="binder" title="Pay now" subtitle="The server works out the price from the current price list. You will be taken to Paystack to finish.">
          {wards.length === 0 ? (
            <EmptyState icon={CreditCard} title="Add a child first" text="Once a child is added, you can pay for their lessons here." />
          ) : (
            <div className="space-y-4">
              <ul className="grid gap-2 sm:grid-cols-2">
                {wards.map((w) => {
                  const a = wardAccess.find((x) => x.studentId === w._id);
                  const on = picked.includes(w._id);
                  return (
                    <li key={w._id}>
                      <label className={`flex items-center gap-3 rounded-2xl border px-4 py-3 cursor-pointer ${on ? "border-[var(--lp-green)] bg-[var(--lp-green-soft)]" : "border-[var(--color-card-border)]"}`}>
                        <input type="checkbox" checked={on} onChange={() => setPicked((p) => (on ? p.filter((x) => x !== w._id) : [...p, w._id]))} />
                        <span className="flex-1 min-w-0"><span className="font-medium block truncate">{w.firstName} {w.lastName}</span>
                          {a?.access.until && <span className="text-xs text-[var(--color-muted)]">until {day(a.access.until)}</span>}</span>
                        {a && <StatusPill status={a.access.reason} />}
                      </label>
                    </li>
                  );
                })}
              </ul>
              <div className="flex flex-wrap items-center gap-3">
                <div role="group" aria-label="Currency" className="inline-flex rounded-full border border-[var(--color-card-border)] p-1">
                  {(["NGN", "USD"] as Currency[]).map((c) => (
                    <button key={c} type="button" onClick={() => setCurrency(c)} aria-pressed={currency === c}
                      className={`px-4 py-1.5 rounded-full text-sm font-semibold ${currency === c ? "bg-[var(--lp-green-deep)] text-white" : ""}`}>{c}</button>
                  ))}
                </div>
                <button className="btn btn-primary" onClick={pay} disabled={checkout.status === "loading"}>
                  {checkout.status === "loading" ? <Loader2 className="animate-spin" size={16} /> : <CreditCard size={16} />} Pay with Paystack
                </button>
              </div>
            </div>
          )}
        </Panel>
      )}

      <Panel title="History" actions={
        <Select className="form-input !w-auto !min-h-0 !py-1.5" value={filter} onChange={(e) => setFilter(e.target.value as any)}>
          <option value="">All</option><option value="success">Successful</option><option value="pending">Pending</option><option value="failed">Failed</option><option value="abandoned">Abandoned</option>
        </Select>}>
        {status === "loading" && !items.length ? <div className="flex justify-center py-8"><Loader2 className="animate-spin" /></div>
          : items.length === 0 ? <EmptyState icon={Receipt} title="No payments yet" />
          : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left"><th>Date</th>{isAdmin && <th>Parent</th>}<th>Children</th><th>Plan</th><th>Amount</th><th>Status</th><th>Reference</th></tr></thead>
              <tbody>
                {items.map((t) => (
                  <tr key={t._id}>
                    <td>{day(t.paidAt || t.createdAt)}</td>
                    {isAdmin && <td>{personName(t.parentId) || t.payerEmail}</td>}
                    <td>{t.studentIds.map(personName).filter(Boolean).join(", ") || "-"}</td>
                    <td>{t.planName || t.items[0]?.name || "-"}</td>
                    <td className="font-medium">{money(t.amount, t.currency)}</td>
                    <td><StatusPill status={t.status} /></td>
                    <td className="font-mono text-xs">{t.reference}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {!isAdmin && successTotal > 0 && <p className="text-xs text-[var(--color-muted)] mt-3">Total paid ({currency}): {money(successTotal, currency)}</p>}
      </Panel>
    </div>
  );
}
