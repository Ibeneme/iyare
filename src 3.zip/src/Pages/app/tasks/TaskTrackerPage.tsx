import Select from "../../../components/ui/Select";
import DateInput from "../../../components/ui/DateInput";
import { useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";
import { Send } from "lucide-react";
import { useAppDispatch, useAppSelector } from "../../../store";
import { fetchTracker, assignTask } from "../../../store/features/tasks/tasks.slice";
import { fetchAllUsersByType } from "../../../store/features/users/users.slice";
import type { TaskPriority, TaskStatus } from "../../../store/models";
import { PageHeader, Panel, EmptyState, StatusPill, Avatar } from "../../../components/ui";
import { day, personName } from "../../../lib/format";

export default function TaskTrackerPage() {
  const dispatch = useAppDispatch();
  const { tracker, perAssignee } = useAppSelector((s) => s.tasks);
  const teachers = useAppSelector((s) => (s.users as any).allUsers?.teacher ?? []) as Array<{ _id: string; firstName: string; lastName: string }>;
  const [filter, setFilter] = useState<{ status: "" | TaskStatus; overdue: boolean }>({ status: "", overdue: false });
  const [form, setForm] = useState({ assigneeId: "", title: "", description: "", priority: "medium" as TaskPriority, dueDate: "" });

  const load = () => dispatch(fetchTracker({ status: filter.status || undefined, overdue: filter.overdue || undefined }));
  useEffect(() => void dispatch(fetchAllUsersByType("teacher")), [dispatch]);
  useEffect(() => void load(), [filter.status, filter.overdue]); // eslint-disable-line

  const nameOf = useMemo(() => Object.fromEntries(teachers.map((t) => [t._id, `${t.firstName} ${t.lastName}`])), [teachers]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.assigneeId || !form.title.trim()) return toast.error("Pick a teacher and give the task a title");
    const r = await dispatch(assignTask({ ...form, dueDate: form.dueDate || undefined, description: form.description || undefined, assigneeType: "teacher" }));
    if (assignTask.fulfilled.match(r)) {
      toast.success("Task assigned");
      setForm({ ...form, title: "", description: "", dueDate: "" });
      load();
    } else toast.error(String(r.payload));
  };

  return (
    <div className="page">
      <PageHeader eyebrow="Admin" title="Task tracker" highlight="tracker" subtitle="Assign work to teachers and see where everything stands." />

      <Panel title="Assign a task">
        <form onSubmit={submit} className="grid gap-3 md:grid-cols-[1.4fr_2fr_1fr_1fr_auto] items-end">
          <label><span className="form-label">Teacher</span>
            <Select className="form-input" value={form.assigneeId} onChange={(e) => setForm({ ...form, assigneeId: e.target.value })}>
              <option value="">Choose…</option>
              {teachers.map((t) => <option key={t._id} value={t._id}>{t.firstName} {t.lastName}</option>)}
            </Select>
          </label>
          <label><span className="form-label">Title</span><input className="form-input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></label>
          <label><span className="form-label">Priority</span>
            <Select className="form-input" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as TaskPriority })}>
              <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
            </Select>
          </label>
          <label><span className="form-label">Due</span><DateInput type="date" className="form-input" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} /></label>
          <button className="btn btn-primary" type="submit"><Send size={16} /> Assign</button>
        </form>
      </Panel>

      <Panel
        title="All tasks"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Select className="form-input !w-auto !min-h-0 !py-1.5" value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value as any })}>
              <option value="">Any status</option><option value="todo">To do</option><option value="in_progress">In progress</option><option value="done">Done</option>
            </Select>
            <label className="inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={filter.overdue} onChange={(e) => setFilter({ ...filter, overdue: e.target.checked })} /> Overdue only</label>
          </div>
        }
      >
        {tracker.length === 0 ? (
          <EmptyState title="No tasks match" text="Try clearing the filters or assign a task above." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left"><th>Task</th><th>Assigned to</th><th>Due</th><th>Priority</th><th>Status</th></tr></thead>
              <tbody>
                {tracker.map((t) => {
                  const id = typeof t.assignedTo.id === "string" ? t.assignedTo.id : t.assignedTo.id._id;
                  const counts = perAssignee[id];
                  return (
                    <tr key={t._id}>
                      <td className="font-medium">{t.title}</td>
                      <td><span className="inline-flex items-center gap-2 align-middle"><Avatar name={personName(t.assignedTo.id) || nameOf[id]} size={26} /></span> {personName(t.assignedTo.id) || nameOf[id] || "-"}{counts && <span className="text-xs text-[var(--color-muted)] ml-2">{counts.done ?? 0}/{(counts.todo ?? 0) + (counts.in_progress ?? 0) + (counts.done ?? 0)} done</span>}</td>
                      <td>{day(t.dueDate)}</td>
                      <td><StatusPill status={t.priority} /></td>
                      <td><StatusPill status={t.status} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
